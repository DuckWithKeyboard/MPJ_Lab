package com.example.onlinebankingsystem.controller;

import com.example.onlinebankingsystem.dto.TransactionDto;
import com.example.onlinebankingsystem.dto.TransactionFilterParams;
import com.example.onlinebankingsystem.dto.TransferRequestDto;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.service.ReceiptService;
import com.example.onlinebankingsystem.service.TransactionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private ReceiptService receiptService;

    // Endpoint to perform a fund transfer
    @PostMapping("/transfer")
    @PreAuthorize("isAuthenticated()") // User must be logged in
    public ResponseEntity<?> transferFunds(@Valid @RequestBody TransferRequestDto transferRequest) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        try {
            TransactionDto transactionDto = transactionService.transferFunds(transferRequest, currentUsername);
            return ResponseEntity.ok(transactionDto);
        } catch (IllegalArgumentException e) {
            // Handle specific errors like account not found, insufficient funds
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (SecurityException e) {
            // Handle authorization errors (user doesn't own source account)
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            // Generic error handler
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred during the transfer: " + e.getMessage());
        }
    }

    // Endpoint to get transaction history for a specific account
    @GetMapping("/{accountNumber}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getTransactionHistory(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        try {
            List<TransactionDto> history = transactionService.getTransactionHistory(accountNumber, currentUsername);
            return ResponseEntity.ok(history);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving transaction history: " + e.getMessage());
        }
    }

    // Endpoint to get last 10 transactions (mini statement) for a specific account
    @GetMapping("/{accountNumber}/recent")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getRecentTransactions(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        try {
            List<TransactionDto> recent = transactionService.getRecentTransactions(accountNumber, currentUsername);
            return ResponseEntity.ok(recent);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving recent transactions: " + e.getMessage());
        }
    }

    // Endpoint to get filtered transaction history for a specific account
    @GetMapping("/history/{accountNumber}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getFilteredHistory(
            @PathVariable String accountNumber,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) BigDecimal minAmount,
            @RequestParam(required = false) BigDecimal maxAmount) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        // Parse startDate
        LocalDateTime parsedStartDate = null;
        if (startDate != null) {
            try {
                parsedStartDate = startDate.length() == 16
                    ? LocalDateTime.parse(startDate + ":00")
                    : LocalDateTime.parse(startDate);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Invalid date format. Use ISO-8601: yyyy-MM-ddTHH:mm:ss");
            }
        }

        // Parse endDate
        LocalDateTime parsedEndDate = null;
        if (endDate != null) {
            try {
                parsedEndDate = endDate.length() == 16
                    ? LocalDateTime.parse(endDate + ":00")
                    : LocalDateTime.parse(endDate);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Invalid date format. Use ISO-8601: yyyy-MM-ddTHH:mm:ss");
            }
        }

        // Parse type
        Transaction.TransactionType parsedType = null;
        if (type != null) {
            try {
                parsedType = Transaction.TransactionType.valueOf(type);
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body("Invalid transaction type: " + type);
            }
        }

        TransactionFilterParams filter = new TransactionFilterParams(parsedStartDate, parsedEndDate, parsedType, minAmount, maxAmount);

        try {
            List<TransactionDto> result = transactionService.getFilteredHistory(accountNumber, filter, currentUsername);
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }

    // Endpoint to download full transaction history as PDF
    @GetMapping("/{accountNumber}/history-pdf")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadHistoryPdf(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        try {
            byte[] pdf = receiptService.generateHistoryPdf(accountNumber, authentication.getName());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", "history-" + accountNumber + ".pdf");
            return new ResponseEntity<>(pdf, headers, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage().getBytes());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage().getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate history PDF.".getBytes());
        }
    }

    // Endpoint to download a PDF receipt for a specific transaction
    @GetMapping("/{id}/receipt")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadReceipt(@PathVariable Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        try {
            byte[] pdfBytes = receiptService.generateReceipt(id, authentication.getName());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", "receipt-" + id + ".pdf");
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage().getBytes());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage().getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate receipt.".getBytes());
        }
    }
}
