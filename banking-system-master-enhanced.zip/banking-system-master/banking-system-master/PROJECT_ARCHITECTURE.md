# Online Banking System - Project Architecture Documentation

## Table of Contents
1. [System Overview](#system-overview)
2. [Technology Stack](#technology-stack)
3. [Architecture Pattern](#architecture-pattern)
4. [Project Structure](#project-structure)
5. [Layer-by-Layer Analysis](#layer-by-layer-analysis)
6. [Security Architecture](#security-architecture)
7. [Data Flow & Request Lifecycle](#data-flow--request-lifecycle)
8. [Database Schema](#database-schema)
9. [API Endpoints](#api-endpoints)

---

## System Overview

This is a RESTful banking system built with Spring Boot 3.x that provides secure user authentication, account management, and fund transfer capabilities. The system follows a layered architecture pattern with JWT-based stateless authentication.

### Core Features
- User registration and JWT-based authentication
- Multiple bank accounts per user
- Secure fund transfers between accounts
- Transaction history tracking
- Role-based access control

---

## Technology Stack

### Backend Framework
- **Spring Boot 3.3.1** - Main application framework
- **Java 17** - Programming language
- **Maven** - Build and dependency management

### Spring Modules
- **Spring Web** - REST API development
- **Spring Data JPA** - Database abstraction layer
- **Spring Security** - Authentication and authorization
- **Spring Validation** - Input validation

### Database
- **PostgreSQL** - Relational database
- **Hibernate** - ORM implementation (via JPA)

### Security & Authentication
- **JWT (jjwt 0.11.5)** - Token-based authentication
- **BCrypt** - Password hashing

### Utilities
- **Lombok** - Reduces boilerplate code (getters, setters, constructors)

---

## Architecture Pattern

The application follows a **Layered Architecture** (also known as N-Tier Architecture):

```
┌─────────────────────────────────────┐
│     Presentation Layer              │
│  (Controllers - REST Endpoints)     │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│      Business Logic Layer           │
│         (Services)                  │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│     Data Access Layer               │
│      (Repositories)                 │
└──────────────┬──────────────────────┘
               │
┌──────────────▼──────────────────────┐
│         Database                    │
│       (PostgreSQL)                  │
└─────────────────────────────────────┘
```

### Cross-Cutting Concerns
- **Security Layer** - JWT filters, authentication
- **DTO Layer** - Data transfer objects for API communication
- **Model Layer** - JPA entities representing database tables

---

## Project Structure

```
src/main/java/com/example/onlinebankingsystem/
├── OnlineBankingSystemApplication.java    # Application entry point
├── controller/                            # REST API endpoints
│   ├── AuthController.java
│   ├── AccountController.java
│   └── TransactionController.java
├── service/                               # Business logic
│   ├── AuthService.java
│   ├── AccountService.java
│   └── TransactionService.java
├── repository/                            # Data access
│   ├── UserRepository.java
│   ├── AccountRepository.java
│   └── TransactionRepository.java
├── model/                                 # JPA entities
│   ├── User.java
│   ├── Account.java
│   └── Transaction.java
├── dto/                                   # Data transfer objects
│   ├── UserRegistrationDto.java
│   ├── AuthenticationRequestDto.java
│   ├── AuthenticationResponseDto.java
│   ├── AccountDto.java
│   ├── TransferRequestDto.java
│   └── TransactionDto.java
└── security/                              # Security configuration
    ├── SecurityConfig.java
    ├── JwtUtil.java
    ├── JwtRequestFilter.java
    ├── JwtAuthenticationEntryPoint.java
    └── UserDetailsServiceImpl.java
```

---

## Layer-by-Layer Analysis

### 1. Application Entry Point

**File:** `OnlineBankingSystemApplication.java`

```java
@SpringBootApplication
public class OnlineBankingSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(OnlineBankingSystemApplication.class, args);
    }
}
```

**Purpose:** Bootstrap the Spring Boot application. The `@SpringBootApplication` annotation enables:
- Component scanning
- Auto-configuration
- Configuration properties

---

### 2. Model Layer (Domain Entities)

These are JPA entities that map directly to database tables.

#### 2.1 User Entity

**File:** `model/User.java`

**Key Features:**
- Implements `UserDetails` interface (Spring Security requirement)
- Stores hashed passwords using BCrypt
- Manages user roles using `@ElementCollection`
- One-to-many relationship with Account (implicit)

**Important Fields:**
- `id` - Primary key (auto-generated)
- `username` - Unique identifier for login
- `password` - BCrypt hashed password
- `email` - Unique email address
- `roles` - Set of role strings (e.g., "ROLE_USER", "ROLE_ADMIN")

**Security Integration:**
- `getAuthorities()` - Converts roles to Spring Security's GrantedAuthority
- Account status methods (isEnabled, isAccountNonLocked, etc.)

#### 2.2 Account Entity

**File:** `model/Account.java`

**Key Features:**
- Represents a bank account
- Many-to-one relationship with User (owner)
- Uses `BigDecimal` for precise monetary calculations
- Automatic timestamp management with `@PrePersist` and `@PreUpdate`

**Important Fields:**
- `id` - Primary key
- `accountNumber` - Unique 12-character identifier (UUID-based)
- `balance` - Current account balance
- `owner` - Reference to User entity (lazy-loaded)
- `createdAt` / `updatedAt` - Audit timestamps

**Lifecycle Callbacks:**
- `@PrePersist` - Sets createdAt and initializes balance to zero
- `@PreUpdate` - Updates updatedAt timestamp

#### 2.3 Transaction Entity

**File:** `model/Transaction.java`

**Key Features:**
- Records all fund transfers
- Many-to-one relationships with Account (from and to)
- Enum-based transaction type classification
- Immutable timestamp (set on creation)

**Important Fields:**
- `id` - Primary key
- `fromAccount` - Source account (nullable for deposits)
- `toAccount` - Destination account
- `amount` - Transfer amount
- `type` - Enum: TRANSFER, DEPOSIT, WITHDRAWAL
- `timestamp` - When transaction occurred
- `description` - Optional notes

---

### 3. Repository Layer (Data Access)

Spring Data JPA repositories provide database operations without boilerplate code.

#### 3.1 UserRepository

**File:** `repository/UserRepository.java`

**Methods:**
- `findByUsername(String username)` - Lookup user for authentication
- `existsByUsername(String username)` - Check username availability
- `existsByEmail(String email)` - Check email availability

**Note:** Extends `JpaRepository<User, Long>` which provides CRUD operations automatically.

#### 3.2 AccountRepository

**File:** `repository/AccountRepository.java`

**Methods:**
- `findByAccountNumber(String accountNumber)` - Lookup account by number
- `findByOwner(User owner)` - Get all accounts for a user
- `findByOwnerUsername(String username)` - Get accounts by username
- `existsByAccountNumber(String accountNumber)` - Check uniqueness

#### 3.3 TransactionRepository

**File:** `repository/TransactionRepository.java`

**Methods:**
- `findByAccountOrderByTimestampDesc(Account account)` - Get transaction history
- `findByAccountIdOrderByTimestampDesc(Long accountId)` - Get history by ID

**Note:** Uses `@Query` annotation for custom JPQL queries to find transactions where an account is either sender or receiver.

---

### 4. Service Layer (Business Logic)

This is where the core business rules and transaction management happen.

#### 4.1 AuthService

**File:** `service/AuthService.java`

**Responsibilities:**
- User registration with validation
- Password hashing
- User authentication
- JWT token generation

**Key Methods:**

**`registerUser(UserRegistrationDto)`**
- Validates username and email uniqueness
- Hashes password using BCrypt
- Assigns default "ROLE_USER" role
- Saves user to database
- Uses `@Transactional` for atomicity

**`authenticateUser(AuthenticationRequestDto)`**
- Delegates to Spring Security's AuthenticationManager
- Validates credentials
- Generates JWT token on success
- Returns token in response DTO

**Dependencies:**
- UserRepository - Database access
- PasswordEncoder - BCrypt hashing
- AuthenticationManager - Spring Security authentication
- JwtUtil - Token generation
- UserDetailsService - Load user details

#### 4.2 AccountService

**File:** `service/AccountService.java`

**Responsibilities:**
- Account creation
- Account retrieval
- Account number generation
- Ownership validation

**Key Methods:**

**`createAccount(String username, BigDecimal initialBalance)`**
- Validates user exists
- Generates unique 12-character account number
- Initializes balance (defaults to zero)
- Returns AccountDto (not entity)

**`getAccountsByUsername(String username)`**
- Retrieves all accounts for a user
- Converts entities to DTOs
- Read-only transaction

**`getAccountByAccountNumber(String accountNumber)`**
- Retrieves specific account
- Returns DTO for API response

**Helper Methods:**
- `generateUniqueAccountNumber()` - UUID-based with uniqueness check
- `convertToDto(Account)` - Entity to DTO conversion

#### 4.3 TransactionService

**File:** `service/TransactionService.java`

**Responsibilities:**
- Fund transfers (most critical operation)
- Transaction history retrieval
- Balance validation
- Ownership verification

**Key Methods:**

**`transferFunds(TransferRequestDto, String currentUsername)`** ⚠️ CRITICAL
- **Transaction Management:** Uses `@Transactional` to ensure atomicity
- **Validation Steps:**
  1. Verify both accounts exist
  2. Verify user owns source account
  3. Verify sufficient funds
- **Transfer Process:**
  1. Deduct from source account
  2. Add to destination account
  3. Save both accounts
  4. Create transaction record
- **Error Handling:**
  - IllegalArgumentException - Account not found or insufficient funds
  - SecurityException - User doesn't own source account

**`getTransactionHistory(String accountNumber, String currentUsername)`**
- Validates account exists
- Verifies ownership
- Retrieves all transactions (sent or received)
- Returns sorted by timestamp (newest first)

**Why @Transactional is Critical:**
If the transfer fails midway (e.g., database error after deducting but before adding), the entire operation rolls back, preventing money loss.

---

### 5. Controller Layer (REST API)

Controllers handle HTTP requests and responses.

#### 5.1 AuthController

**File:** `controller/AuthController.java`

**Base Path:** `/api/auth`

**Endpoints:**

**POST `/api/auth/register`**
- Request: UserRegistrationDto (username, password, email)
- Response: Success message or error
- Status: 201 Created or 400 Bad Request
- Public access (no authentication required)

**POST `/api/auth/login`**
- Request: AuthenticationRequestDto (username, password)
- Response: AuthenticationResponseDto (JWT token)
- Status: 200 OK or 401 Unauthorized
- Public access

**Error Handling:**
- Catches IllegalArgumentException (duplicate username/email)
- Returns appropriate HTTP status codes

#### 5.2 AccountController

**File:** `controller/AccountController.java`

**Base Path:** `/api/accounts`

**Security:** All endpoints require authentication (`@PreAuthorize("isAuthenticated()")`)

**Endpoints:**

**POST `/api/accounts`**
- Request: Optional `{"initialBalance": 100.00}`
- Response: AccountDto
- Status: 201 Created
- Creates account for authenticated user

**GET `/api/accounts`**
- Response: List<AccountDto>
- Returns all accounts owned by authenticated user

**GET `/api/accounts/{accountNumber}`**
- Response: AccountDto
- Status: 200 OK or 403 Forbidden or 404 Not Found
- Includes ownership verification

**Security Features:**
- Extracts username from SecurityContext
- Verifies ownership before returning account details
- Returns 403 Forbidden if user doesn't own the account

#### 5.3 TransactionController

**File:** `controller/TransactionController.java`

**Base Path:** `/api/transactions`

**Security:** All endpoints require authentication

**Endpoints:**

**POST `/api/transactions/transfer`**
- Request: TransferRequestDto (fromAccountNumber, toAccountNumber, amount, description)
- Response: TransactionDto
- Status: 200 OK, 400 Bad Request, or 403 Forbidden
- Performs fund transfer

**GET `/api/transactions/{accountNumber}`**
- Response: List<TransactionDto>
- Returns transaction history for specified account
- Ownership verified in service layer

**Validation:**
- Uses `@Valid` annotation for automatic DTO validation
- Amount must be positive
- Account numbers cannot be blank

---

### 6. DTO Layer (Data Transfer Objects)

DTOs decouple API contracts from internal entity structure.

#### Why DTOs?

1. **Security** - Don't expose password hashes or internal IDs
2. **Flexibility** - API can change without modifying entities
3. **Validation** - Input validation separate from entity validation
4. **Performance** - Send only necessary data

#### Key DTOs:

**UserRegistrationDto**
- Validation: Username (3-50 chars), Password (min 8 chars), Valid email
- Used for registration requests

**AuthenticationRequestDto**
- Simple username/password for login
- Validation: Both fields required

**AuthenticationResponseDto**
- Contains JWT token
- Returned after successful login

**AccountDto**
- Includes ownerUsername instead of full User object
- Safe for API responses

**TransferRequestDto**
- Validation: Amount > 0.01, Account numbers required
- Used for transfer requests

**TransactionDto**
- Uses account numbers instead of Account entities
- Includes transaction type enum

---

## Security Architecture

### JWT Authentication Flow

```
1. User Registration
   ├─> POST /api/auth/register
   ├─> Password hashed with BCrypt
   └─> User saved to database

2. User Login
   ├─> POST /api/auth/login
   ├─> AuthenticationManager validates credentials
   ├─> JWT token generated
   └─> Token returned to client

3. Authenticated Request
   ├─> Client sends: Authorization: Bearer <token>
   ├─> JwtRequestFilter intercepts request
   ├─> Token validated and username extracted
   ├─> UserDetailsService loads user
   ├─> SecurityContext populated
   └─> Request proceeds to controller
```

### Security Components

#### 6.1 SecurityConfig

**File:** `security/SecurityConfig.java`

**Purpose:** Main security configuration

**Key Configurations:**

**CSRF Protection:** Disabled (stateless API)

**Authorization Rules:**
- Public: `/`, `/index.html`, `/*.js`, `/*.css`, `/api/auth/**`
- Protected: All other endpoints require authentication

**Session Management:** Stateless (no server-side sessions)

**Filter Chain:**
- JwtRequestFilter runs before UsernamePasswordAuthenticationFilter
- Validates JWT on every request

**Beans Provided:**
- `PasswordEncoder` - BCrypt with default strength
- `AuthenticationManager` - For credential validation
- `SecurityFilterChain` - Main security configuration

#### 6.2 JwtUtil

**File:** `security/JwtUtil.java`

**Purpose:** JWT token operations

**Configuration:**
- Secret key from `application.properties`
- Expiration time: 86400000ms (24 hours)
- Algorithm: HS512 (HMAC with SHA-512)

**Key Methods:**

**`generateToken(UserDetails)`**
- Creates JWT with username as subject
- Sets issued and expiration dates
- Signs with secret key

**`validateToken(String token, UserDetails)`**
- Verifies username matches
- Checks token not expired

**`extractUsername(String token)`**
- Parses token and extracts subject (username)

**Security Note:**
- Uses `Keys.hmacShaKeyFor()` to ensure key strength
- Falls back to generated key if configured secret is weak

#### 6.3 JwtRequestFilter

**File:** `security/JwtRequestFilter.java`

**Purpose:** Intercepts every HTTP request to validate JWT

**Process:**
1. Extract Authorization header
2. Check for "Bearer " prefix
3. Extract token (substring after "Bearer ")
4. Extract username from token
5. Load UserDetails from database
6. Validate token
7. Set authentication in SecurityContext
8. Continue filter chain

**Error Handling:**
- Logs warnings for invalid/expired tokens
- Doesn't block request (lets Spring Security handle authorization)

#### 6.4 UserDetailsServiceImpl

**File:** `security/UserDetailsServiceImpl.java`

**Purpose:** Load user details for Spring Security

**Implementation:**
- Implements `UserDetailsService` interface
- Queries UserRepository by username
- Returns User entity (which implements UserDetails)
- Throws UsernameNotFoundException if not found

**Integration:**
- Used by AuthenticationManager during login
- Used by JwtRequestFilter to load user details

---

## Data Flow & Request Lifecycle

### Example: Fund Transfer Request

```
1. CLIENT
   └─> POST /api/transactions/transfer
       Headers: Authorization: Bearer <JWT>
       Body: {
         "fromAccountNumber": "abc123",
         "toAccountNumber": "xyz789",
         "amount": 100.00
       }

2. SECURITY LAYER
   ├─> JwtRequestFilter intercepts
   ├─> Validates JWT token
   ├─> Extracts username: "john_doe"
   ├─> Loads UserDetails from database
   └─> Sets SecurityContext authentication

3. CONTROLLER LAYER
   ├─> TransactionController.transferFunds()
   ├─> @Valid validates TransferRequestDto
   ├─> Extracts username from SecurityContext
   └─> Calls TransactionService.transferFunds()

4. SERVICE LAYER (CRITICAL - @Transactional)
   ├─> Validates source account exists
   ├─> Validates destination account exists
   ├─> Verifies "john_doe" owns source account
   ├─> Checks sufficient balance
   ├─> Deducts 100.00 from source
   ├─> Adds 100.00 to destination
   ├─> Saves both accounts
   ├─> Creates Transaction record
   └─> Returns TransactionDto

5. CONTROLLER LAYER
   └─> Returns ResponseEntity with TransactionDto

6. CLIENT
   └─> Receives 200 OK with transaction details
```

### Transaction Rollback Scenario

```
If ANY step fails in the @Transactional method:
├─> Database error after deducting funds
├─> Network interruption
├─> Validation failure
└─> ENTIRE operation rolls back
    ├─> Source account balance restored
    ├─> Destination account unchanged
    └─> No transaction record created
```

---

## Database Schema

### Tables and Relationships

```sql
users
├── id (PK, BIGSERIAL)
├── username (UNIQUE, NOT NULL)
├── password (NOT NULL) -- BCrypt hashed
└── email (UNIQUE, NOT NULL)

user_roles
├── user_id (FK -> users.id)
└── role (VARCHAR) -- e.g., "ROLE_USER"

accounts
├── id (PK, BIGSERIAL)
├── account_number (UNIQUE, NOT NULL)
├── balance (NUMERIC, NOT NULL)
├── user_id (FK -> users.id, NOT NULL)
├── created_at (TIMESTAMP, NOT NULL)
└── updated_at (TIMESTAMP, NOT NULL)

transactions
├── id (PK, BIGSERIAL)
├── from_account_id (FK -> accounts.id, NULLABLE)
├── to_account_id (FK -> accounts.id, NOT NULL)
├── amount (NUMERIC, NOT NULL)
├── timestamp (TIMESTAMP, NOT NULL)
├── type (VARCHAR, NOT NULL) -- TRANSFER, DEPOSIT, WITHDRAWAL
└── description (TEXT, NULLABLE)
```

### Relationships

```
User 1──────* Account
  │
  └─> One user can have multiple accounts

Account *──────* Transaction
  │              │
  └─> fromAccount │
                  └─> toAccount
  
  One account can be involved in many transactions
  (either as sender or receiver)
```

### Indexes (Auto-created by JPA)

- Primary keys on all tables
- Unique indexes on username, email, account_number
- Foreign key indexes on user_id, from_account_id, to_account_id

---

## API Endpoints

### Authentication Endpoints (Public)

| Method | Endpoint | Request Body | Response | Description |
|--------|----------|--------------|----------|-------------|
| POST | `/api/auth/register` | UserRegistrationDto | Success message | Register new user |
| POST | `/api/auth/login` | AuthenticationRequestDto | JWT token | Authenticate and get token |

### Account Endpoints (Authenticated)

| Method | Endpoint | Request Body | Response | Description |
|--------|----------|--------------|----------|-------------|
| POST | `/api/accounts` | `{"initialBalance": 100}` | AccountDto | Create new account |
| GET | `/api/accounts` | - | List<AccountDto> | Get all user's accounts |
| GET | `/api/accounts/{accountNumber}` | - | AccountDto | Get specific account |

### Transaction Endpoints (Authenticated)

| Method | Endpoint | Request Body | Response | Description |
|--------|----------|--------------|----------|-------------|
| POST | `/api/transactions/transfer` | TransferRequestDto | TransactionDto | Transfer funds |
| GET | `/api/transactions/{accountNumber}` | - | List<TransactionDto> | Get transaction history |

---

## Key Design Patterns

### 1. Repository Pattern
- Abstracts data access logic
- Provided by Spring Data JPA
- Reduces boilerplate code

### 2. Service Layer Pattern
- Encapsulates business logic
- Manages transactions
- Coordinates between repositories

### 3. DTO Pattern
- Separates API contracts from domain models
- Provides validation layer
- Enhances security

### 4. Filter Chain Pattern
- JwtRequestFilter in security chain
- Processes requests before controllers
- Enables cross-cutting concerns

### 5. Dependency Injection
- Spring's IoC container
- Constructor/field injection with @Autowired
- Loose coupling between components

---

## Important Modules Highlighted

### 🔴 CRITICAL: TransactionService
- Handles money transfers
- MUST use @Transactional
- Failure here = data inconsistency

### 🔴 CRITICAL: SecurityConfig
- Controls access to all endpoints
- Misconfiguration = security breach
- JWT filter order matters

### 🔴 CRITICAL: JwtUtil
- Token generation and validation
- Secret key must be strong
- Expiration time affects security

### 🟡 IMPORTANT: UserDetailsServiceImpl
- Bridge between Spring Security and database
- Used in authentication flow
- Must return UserDetails implementation

### 🟡 IMPORTANT: JwtRequestFilter
- Runs on every request
- Validates tokens
- Sets security context

### 🟢 SUPPORTING: Controllers
- Thin layer
- Delegates to services
- Handles HTTP concerns only

### 🟢 SUPPORTING: Repositories
- Auto-implemented by Spring Data JPA
- Custom queries when needed
- No business logic

---

## Configuration Files

### application.properties

```properties
# Server
server.port=8080

# Database
spring.datasource.url=jdbc:postgresql://localhost:5432/online_banking_db
spring.datasource.username=postuser
spring.datasource.password=12345

# JPA/Hibernate
spring.jpa.hibernate.ddl-auto=update  # Auto-create/update tables
spring.jpa.show-sql=true              # Log SQL queries

# JWT
jwt.secret=YourVerySecretKeyNeedsToBeLongAndSecureEnough
jwt.expiration.ms=86400000  # 24 hours
```

### pom.xml Dependencies

- spring-boot-starter-web
- spring-boot-starter-data-jpa
- spring-boot-starter-security
- spring-boot-starter-validation
- postgresql (runtime)
- lombok (compile-time)
- jjwt-api, jjwt-impl, jjwt-jackson (JWT)

---

## Summary

This banking system demonstrates a production-ready Spring Boot application with:

1. **Layered Architecture** - Clear separation of concerns
2. **Security First** - JWT authentication, BCrypt hashing, role-based access
3. **Transaction Safety** - @Transactional ensures data consistency
4. **RESTful Design** - Standard HTTP methods and status codes
5. **Validation** - Input validation at DTO level
6. **Best Practices** - DTOs, service layer, repository pattern

The most critical aspect is the transaction management in TransactionService, which ensures that fund transfers are atomic and consistent, preventing data corruption or money loss.
