package com.example.onlinebankingsystem.controller;

import com.example.onlinebankingsystem.dto.AccountDto;
import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> createAccount(@RequestBody(required = false) Map<String, Object> requestBody) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        BigDecimal initialBalance = BigDecimal.ZERO;
        Account.AccountType accountType = Account.AccountType.SAVINGS;

        if (requestBody != null) {
            if (requestBody.containsKey("initialBalance")) {
                initialBalance = new BigDecimal(requestBody.get("initialBalance").toString());
            }
            if (requestBody.containsKey("accountType")) {
                try {
                    accountType = Account.AccountType.valueOf(requestBody.get("accountType").toString().toUpperCase());
                } catch (IllegalArgumentException e) {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid account type. Use SAVINGS or CHECKING.");
                }
            }
        }

        try {
            AccountDto newAccount = accountService.createAccount(username, initialBalance, accountType);
            return ResponseEntity.status(HttpStatus.CREATED).body(newAccount);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error creating account: " + e.getMessage());
        }
    }

    // Endpoint to get all accounts for the authenticated user
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getUserAccounts() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        try {
            List<AccountDto> accounts = accountService.getAccountsByUsername(username);
            return ResponseEntity.ok(accounts);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving accounts: " + e.getMessage());
        }
    }

    // Endpoint to get a specific account by its number
    // Security: Ensure the authenticated user owns this account
    @GetMapping("/{accountNumber}")
    @PreAuthorize("isAuthenticated()") // Basic check: user must be logged in
    public ResponseEntity<?> getAccountByNumber(@PathVariable String accountNumber) {
         Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
         String currentUsername = authentication.getName();

        try {
            AccountDto accountDto = accountService.getAccountByAccountNumber(accountNumber);

            // Authorization check: Does the current user own this account?
            if (!accountDto.getOwnerUsername().equals(currentUsername)) {
                 // Consider if admins should bypass this check - requires role management
                 return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Access denied: You do not own this account.");
            }

            return ResponseEntity.ok(accountDto);
        } catch (IllegalArgumentException e) { // Specific exception for account not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving account: " + e.getMessage());
        }
    }

    /**
     * [TRANSFER-VERIFY] Looks up an account by number and returns the owner's username.
     * Used on the transfer page to show the recipient's name after both inputs match.
     * Any authenticated user can call this — it only returns the username, not balance.
     */
    @GetMapping("/lookup/{accountNumber}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> lookupAccount(@PathVariable String accountNumber) {
        try {
            AccountDto accountDto = accountService.getAccountByAccountNumber(accountNumber);
            return ResponseEntity.ok(Map.of("ownerUsername", accountDto.getOwnerUsername()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Account not found.");
        }
    }
}
