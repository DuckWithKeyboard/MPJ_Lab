package com.example.onlinebankingsystem.controller;

import com.example.onlinebankingsystem.dto.AuthenticationRequestDto;
import com.example.onlinebankingsystem.dto.AuthenticationResponseDto;
import com.example.onlinebankingsystem.dto.UserRegistrationDto;
import com.example.onlinebankingsystem.model.User;
import com.example.onlinebankingsystem.repository.UserRepository;
import com.example.onlinebankingsystem.service.AuthService;
import com.example.onlinebankingsystem.service.OtpService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    // [FORGOT-PASSWORD] Needed to look up user by email and save new password
    @Autowired private UserRepository userRepository;
    @Autowired private OtpService otpService;
    @Autowired private PasswordEncoder passwordEncoder;

    // Endpoint for user registration (unchanged)
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegistrationDto registrationDto) {
        try {
            authService.registerUser(registrationDto);
            return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully!");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred during registration.");
        }
    }

    /**
     * [2FA] STEP 1 — Login endpoint.
     * Previously returned a JWT. Now verifies credentials, sends an OTP email,
     * and returns { "status": "OTP_SENT" } so the frontend shows the OTP screen.
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody AuthenticationRequestDto authRequest) {
        try {
            String status = authService.initiateLogin(authRequest);
            // [2FA] Return OTP_SENT status — frontend will show the OTP input panel
            return ResponseEntity.ok(Map.of("status", status));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body("Authentication failed: " + e.getMessage());
        }
    }

    /**
     * [2FA] STEP 2 — OTP verification endpoint (NEW).
     * Accepts { "username": "...", "code": "123456" }.
     * If the OTP is valid, returns the JWT so the frontend can proceed to dashboard.
     */
    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String code     = body.get("code");

        if (username == null || code == null) {
            return ResponseEntity.badRequest().body("username and code are required.");
        }

        try {
            // [2FA] Verify the OTP — returns JWT on success
            AuthenticationResponseDto response = authService.verifyOtpAndLogin(username, code);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            // Invalid or expired OTP
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Verification failed: " + e.getMessage());
        }
    }

    /**
     * [FORGOT-PASSWORD] STEP 1 — Accept email, send OTP if account exists.
     * Always returns 200 even if email not found (prevents email enumeration).
     * Request body: { "email": "user@example.com" }
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> body) {
        String email = body.get("email");
        if (email == null || email.isBlank()) {
            return ResponseEntity.badRequest().body("Email is required.");
        }

        // Look up user by email — send OTP only if found
        Optional<User> userOpt = userRepository.findByEmail(email.trim().toLowerCase());
        if (userOpt.isPresent()) {
            // [FORGOT-PASSWORD] Send reset OTP asynchronously
            otpService.generateAndSendPasswordResetOtp(email.trim().toLowerCase());
        }

        // Always return the same response to prevent email enumeration attacks
        return ResponseEntity.ok(Map.of("status", "OTP_SENT"));
    }

    /**
     * [FORGOT-PASSWORD] STEP 2 — Verify OTP and set new password.
     * Request body: { "email": "...", "code": "123456", "newPassword": "..." }
     */
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> body) {
        String email       = body.get("email");
        String code        = body.get("code");
        String newPassword = body.get("newPassword");

        if (email == null || code == null || newPassword == null) {
            return ResponseEntity.badRequest().body("email, code, and newPassword are required.");
        }
        if (newPassword.length() < 8) {
            return ResponseEntity.badRequest().body("Password must be at least 8 characters.");
        }

        // [FORGOT-PASSWORD] Verify the OTP
        if (!otpService.verifyPasswordResetOtp(email.trim().toLowerCase(), code)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body("Invalid or expired reset code.");
        }

        // OTP valid — find the user and update their password
        Optional<User> userOpt = userRepository.findByEmail(email.trim().toLowerCase());
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Account not found.");
        }

        User user = userOpt.get();
        // Hash the new password before saving
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        return ResponseEntity.ok("Password reset successfully. You can now log in.");
    }
}
