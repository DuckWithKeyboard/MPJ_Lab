package com.example.onlinebankingsystem.controller;

import com.example.onlinebankingsystem.dto.TransactionDto;
import com.example.onlinebankingsystem.dto.TransactionFilterParams;
import com.example.onlinebankingsystem.dto.TransferRequestDto;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.repository.UserRepository;
import com.example.onlinebankingsystem.service.OtpService;
import com.example.onlinebankingsystem.service.ReceiptService;
import com.example.onlinebankingsystem.service.TransactionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private ReceiptService receiptService;

    // [TRANSFER-OTP] Used to send and verify transfer confirmation OTPs
    @Autowired
    private OtpService otpService;

    // [TRANSFER-OTP] Used to look up the logged-in user's email
    @Autowired
    private UserRepository userRepository;

    /**
     * [TRANSFER-OTP] STEP 1 — Send an OTP before executing a transfer.
     * Validates the request body, then emails a 6-digit code to the logged-in user.
     * The actual transfer is NOT executed here.
     */
    @PostMapping("/transfer/request-otp")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> requestTransferOtp(@Valid @RequestBody TransferRequestDto transferRequest) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName();

        var userOpt = userRepository.findByUsername(username);
        if (userOpt.isEmpty()) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found.");

        // [TRANSFER-OTP] Send OTP with transfer details in the email body
        otpService.generateAndSendTransferOtp(
            username, userOpt.get().getEmail(),
            transferRequest.getToAccountNumber(),
            transferRequest.getAmount().toPlainString()
        );
        return ResponseEntity.ok(Map.of("status", "OTP_SENT"));
    }

    /**
     * [TRANSFER-OTP] STEP 2 — Verify OTP then execute the transfer.
     * otpCode is passed as a query parameter alongside the transfer body.
     */
    @PostMapping("/transfer")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> transferFunds(
            @Valid @RequestBody TransferRequestDto transferRequest,
            @RequestParam String otpCode) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = auth.getName();

        // [TRANSFER-OTP] Reject if OTP is invalid or expired
        if (!otpService.verifyTransferOtp(currentUsername, otpCode)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body("Invalid or expired verification code.");
        }

        try {
            TransactionDto transactionDto = transactionService.transferFunds(transferRequest, currentUsername);
            return ResponseEntity.ok(transactionDto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An error occurred during the transfer: " + e.getMessage());
        }
    }

    // Endpoint to get transaction history for a specific account
    @GetMapping("/{accountNumber}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getTransactionHistory(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        try {
            List<TransactionDto> history = transactionService.getTransactionHistory(accountNumber, currentUsername);
            return ResponseEntity.ok(history);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving transaction history: " + e.getMessage());
        }
    }

    // Endpoint to get last 10 transactions (mini statement) for a specific account
    @GetMapping("/{accountNumber}/recent")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getRecentTransactions(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        try {
            List<TransactionDto> recent = transactionService.getRecentTransactions(accountNumber, currentUsername);
            return ResponseEntity.ok(recent);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving recent transactions: " + e.getMessage());
        }
    }

    // Endpoint to get filtered transaction history for a specific account
    @GetMapping("/history/{accountNumber}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<?> getFilteredHistory(
            @PathVariable String accountNumber,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) BigDecimal minAmount,
            @RequestParam(required = false) BigDecimal maxAmount) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentUsername = authentication.getName();

        // Parse startDate
        LocalDateTime parsedStartDate = null;
        if (startDate != null) {
            try {
                parsedStartDate = startDate.length() == 16
                    ? LocalDateTime.parse(startDate + ":00")
                    : LocalDateTime.parse(startDate);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Invalid date format. Use ISO-8601: yyyy-MM-ddTHH:mm:ss");
            }
        }

        // Parse endDate
        LocalDateTime parsedEndDate = null;
        if (endDate != null) {
            try {
                parsedEndDate = endDate.length() == 16
                    ? LocalDateTime.parse(endDate + ":00")
                    : LocalDateTime.parse(endDate);
            } catch (Exception e) {
                return ResponseEntity.badRequest().body("Invalid date format. Use ISO-8601: yyyy-MM-ddTHH:mm:ss");
            }
        }

        // Parse type
        Transaction.TransactionType parsedType = null;
        if (type != null) {
            try {
                parsedType = Transaction.TransactionType.valueOf(type);
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body("Invalid transaction type: " + type);
            }
        }

        TransactionFilterParams filter = new TransactionFilterParams(parsedStartDate, parsedEndDate, parsedType, minAmount, maxAmount);

        try {
            List<TransactionDto> result = transactionService.getFilteredHistory(accountNumber, filter, currentUsername);
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        }
    }

    // Endpoint to download full transaction history as PDF
    @GetMapping("/{accountNumber}/history-pdf")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadHistoryPdf(@PathVariable String accountNumber) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        try {
            byte[] pdf = receiptService.generateHistoryPdf(accountNumber, authentication.getName());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", "history-" + accountNumber + ".pdf");
            return new ResponseEntity<>(pdf, headers, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage().getBytes());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage().getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate history PDF.".getBytes());
        }
    }

    // Endpoint to download a PDF receipt for a specific transaction
    @GetMapping("/{id}/receipt")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadReceipt(@PathVariable Long id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        try {
            byte[] pdfBytes = receiptService.generateReceipt(id, authentication.getName());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", "receipt-" + id + ".pdf");
            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage().getBytes());
        } catch (SecurityException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage().getBytes());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate receipt.".getBytes());
        }
    }
}
