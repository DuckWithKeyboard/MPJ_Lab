package com.example.onlinebankingsystem.docs;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Generates SecureBank-Code-Documentation.pdf using Apache PDFBox 3.0.2.
 * Run via: mvn compile exec:java -Dexec.mainClass="com.example.onlinebankingsystem.docs.GenerateDocs"
 */
public class GenerateDocs {

    // ── Fonts ──────────────────────────────────────────────────────────────────
    private static PDType1Font FONT_REGULAR;
    private static PDType1Font FONT_BOLD;
    private static PDType1Font FONT_MONO;

    // ── Colours ────────────────────────────────────────────────────────────────
    private static final Color BLUE_HEADER  = new Color(0x1A, 0x53, 0x9E);
    private static final Color BLUE_LIGHT   = new Color(0xE8, 0xF0, 0xFB);
    private static final Color GRAY_CODE_BG = new Color(0xF4, 0xF4, 0xF4);
    private static final Color GRAY_TEXT    = new Color(0x44, 0x44, 0x44);
    private static final Color WHITE        = Color.WHITE;
    private static final Color BLACK        = Color.BLACK;

    // ── Page geometry ──────────────────────────────────────────────────────────
    private static final float PAGE_W  = PDRectangle.A4.getWidth();   // 595
    private static final float PAGE_H  = PDRectangle.A4.getHeight();  // 842
    private static final float MARGIN  = 50f;
    private static final float CONTENT_W = PAGE_W - 2 * MARGIN;

    // ── State ──────────────────────────────────────────────────────────────────
    private final PDDocument doc = new PDDocument();
    private PDPage           currentPage;
    private PDPageContentStream cs;
    private float cursorY;
    private int   pageNumber = 0;

    // TOC entries collected during first pass
    private final List<String[]> tocEntries = new ArrayList<>(); // [title, pageNum]

    public static void main(String[] args) throws Exception {
        FONT_REGULAR = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        FONT_BOLD    = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        FONT_MONO    = new PDType1Font(Standard14Fonts.FontName.COURIER);

        new GenerateDocs().generate();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  TOP-LEVEL ORCHESTRATION
    // ══════════════════════════════════════════════════════════════════════════
    private void generate() throws IOException {
        buildCoverPage();
        buildTocPage();
        buildSection1();
        buildSection2();
        buildSection3();
        buildSection4();
        buildSection5();
        buildSection6();
        buildSection7();
        buildSection8();
        buildSection9();
        buildSection10();
        buildSection11();

        closeCurrentPage();

        String outPath = "docs/SecureBank-Code-Documentation.pdf";
        new File("docs").mkdirs();
        doc.save(outPath);
        doc.close();
        System.out.println("PDF saved to: " + outPath);
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  COVER PAGE
    // ══════════════════════════════════════════════════════════════════════════
    private void buildCoverPage() throws IOException {
        newPage();

        // Blue header bar
        fillRect(0, PAGE_H - 160, PAGE_W, 160, BLUE_HEADER);

        // Title
        drawCenteredText("SecureBank", FONT_BOLD, 36, WHITE, PAGE_H - 70);
        drawCenteredText("Complete Code Documentation", FONT_BOLD, 22, WHITE, PAGE_H - 108);
        drawCenteredText("A Beginner's Guide to the Codebase", FONT_REGULAR, 14, new Color(0xCC, 0xDD, 0xFF), PAGE_H - 135);

        // Decorative line
        fillRect(MARGIN, PAGE_H - 175, CONTENT_W, 3, BLUE_HEADER);

        // Body text
        float y = PAGE_H - 220;
        drawCenteredText("This document explains every file in the SecureBank", FONT_REGULAR, 12, GRAY_TEXT, y);
        y -= 18;
        drawCenteredText("Spring Boot banking application, chunk by chunk.", FONT_REGULAR, 12, GRAY_TEXT, y);
        y -= 18;
        drawCenteredText("No prior Spring Boot experience required.", FONT_REGULAR, 12, GRAY_TEXT, y);

        // Date
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy"));
        y -= 50;
        drawCenteredText("Generated: " + date, FONT_REGULAR, 11, GRAY_TEXT, y);

        // Section list preview box
        y -= 40;
        fillRect(MARGIN, y - 220, CONTENT_W, 230, BLUE_LIGHT);
        drawRect(MARGIN, y - 220, CONTENT_W, 230, BLUE_HEADER, 1);
        y -= 15;
        drawText("Contents at a Glance:", FONT_BOLD, 12, BLUE_HEADER, MARGIN + 10, y);
        y -= 20;
        String[] sections = {
            "1. What is Spring Boot?",
            "2. What is JWT?",
            "3. Project Structure Overview",
            "4. Entry Point",
            "5. Data Models (model/)",
            "6. Security Layer (security/)",
            "7. Service Layer (service/)",
            "8. Controllers (controller/)",
            "9. Receipt & PDF Generation",
            "10. Frontend (shared.js)",
            "11. application.properties"
        };
        for (String s : sections) {
            drawText("  \u2022  " + s, FONT_REGULAR, 11, GRAY_TEXT, MARGIN + 10, y);
            y -= 17;
        }

        closeCurrentPage();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  TABLE OF CONTENTS
    // ══════════════════════════════════════════════════════════════════════════
    private void buildTocPage() throws IOException {
        newPage();
        sectionHeading("Table of Contents", null);
        cursorY -= 10;

        String[][] toc = {
            {"Cover Page",                              "1"},
            {"Table of Contents",                       "2"},
            {"Section 1: What is Spring Boot?",         "3"},
            {"Section 2: What is JWT?",                 "4"},
            {"Section 3: Project Structure Overview",   "5"},
            {"Section 4: Entry Point",                  "6"},
            {"Section 5: Data Models (model/)",         "7"},
            {"  5.1  User.java",                        "7"},
            {"  5.2  Account.java",                     "9"},
            {"  5.3  Transaction.java",                 "10"},
            {"Section 6: Security Layer (security/)",   "11"},
            {"  6.1  SecurityConfig.java",              "11"},
            {"  6.2  JwtUtil.java",                     "13"},
            {"  6.3  JwtRequestFilter.java",            "15"},
            {"Section 7: Service Layer (service/)",     "17"},
            {"  7.1  AuthService.java",                 "17"},
            {"  7.2  TransactionService.java",          "19"},
            {"Section 8: Controllers (controller/)",    "21"},
            {"  8.1  AuthController.java",              "21"},
            {"  8.2  TransactionController.java",       "22"},
            {"Section 9: Receipt & PDF Generation",     "24"},
            {"Section 10: Frontend (shared.js)",        "26"},
            {"Section 11: application.properties",      "28"},
        };

        for (String[] row : toc) {
            ensureSpace(20);
            boolean isSection = !row[0].startsWith("  ");
            PDType1Font f = isSection ? FONT_BOLD : FONT_REGULAR;
            float sz = isSection ? 12f : 11f;
            drawText(row[0], f, sz, isSection ? BLUE_HEADER : GRAY_TEXT, MARGIN, cursorY);
            // Dots
            float dotStart = MARGIN + textWidth(row[0], f, sz) + 4;
            float dotEnd   = PAGE_W - MARGIN - textWidth(row[1], FONT_REGULAR, 11) - 4;
            drawDots(dotStart, dotEnd, cursorY);
            drawText(row[1], FONT_REGULAR, 11, GRAY_TEXT, PAGE_W - MARGIN - textWidth(row[1], FONT_REGULAR, 11), cursorY);
            cursorY -= isSection ? 20 : 16;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 1 — Spring Boot
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection1() throws IOException {
        newPage();
        sectionHeading("Section 1: What is Spring Boot?", "1");
        para("Spring Boot is a framework that makes it easy to build Java web applications. "
           + "It handles a lot of setup automatically so you can focus on writing business logic "
           + "instead of configuration.");
        para("When you run the app, Spring Boot starts a web server (Tomcat) inside your program "
           + "— you don't need to install a separate server. It also auto-configures the database "
           + "connection, security, and many other things based on the libraries you include.");
        subHeading("Key ideas:");
        bullet("Auto-configuration: Spring Boot reads your dependencies and sets up sensible defaults.");
        bullet("Embedded server: Tomcat runs inside the JAR — just run java -jar app.jar.");
        bullet("Convention over configuration: follow naming conventions and things just work.");
        bullet("Starter dependencies: spring-boot-starter-web pulls in everything needed for a web app.");
        para("The entry point is a class annotated with @SpringBootApplication. When you call "
           + "SpringApplication.run(...), Spring scans all your classes, wires them together, "
           + "and starts the server on port 8080.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 2 — JWT
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection2() throws IOException {
        newPage();
        sectionHeading("Section 2: What is JWT (JSON Web Token)?", "2");
        para("JWT is a way to prove who you are without sending your password every time. "
           + "When you log in, the server gives you a token (a long string). You send this token "
           + "with every subsequent request. The server checks the token to know who you are.");
        subHeading("Token structure — three parts separated by dots:");
        codeBlock(new String[]{
            "Header.Payload.Signature",
            "",
            "eyJhbGciOiJIUzUxMiJ9   <-- Header  (algorithm used)",
            ".eyJzdWIiOiJhbGljZSJ9  <-- Payload (username, expiry)",
            ".SflKxwRJSMeKKF2QT4fw  <-- Signature (proves it wasn't tampered)"
        });
        para("The Header says which algorithm was used to sign the token (HS512 in our case). "
           + "The Payload contains claims — data like the username and expiry time. "
           + "The Signature is a cryptographic hash of Header+Payload using a secret key. "
           + "If anyone changes the Payload, the Signature won't match and the server rejects it.");
        subHeading("Why not just use sessions?");
        bullet("Sessions require the server to store state (a session table or memory). JWT is stateless.");
        bullet("Stateless means any server instance can verify the token — great for scaling.");
        bullet("The token is self-contained: the server doesn't need to look anything up.");
        subHeading("How it flows in SecureBank:");
        bullet("1. User POSTs username+password to /api/auth/login.");
        bullet("2. Server verifies credentials, generates a JWT signed with the secret key.");
        bullet("3. Client stores the JWT in sessionStorage.");
        bullet("4. Every subsequent request includes: Authorization: Bearer <token>.");
        bullet("5. JwtRequestFilter intercepts the request, validates the token, sets authentication.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 3 — Project Structure
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection3() throws IOException {
        newPage();
        sectionHeading("Section 3: Project Structure Overview", "3");
        para("The project follows a standard layered architecture. Each package has a single responsibility:");
        codeBlock(new String[]{
            "src/main/java/com/example/onlinebankingsystem/",
            "  model/        Database table definitions (User, Account, Transaction)",
            "  repository/   Database query interfaces (Spring Data JPA)",
            "  service/      Business logic (rules, calculations, validation)",
            "  controller/   HTTP endpoints (what the browser calls)",
            "  security/     JWT creation, validation, and request filtering",
            "  dto/          Data shapes sent to/from the browser (no entity exposure)",
            "  docs/         This documentation generator",
            "",
            "src/main/resources/",
            "  application.properties   Database URL, JWT secret, server config",
            "  static/                  HTML, CSS, JS frontend files"
        });
        subHeading("Why separate layers?");
        bullet("model/ — only knows about the database. No HTTP, no business rules.");
        bullet("repository/ — only knows how to query the database. No HTTP, no business rules.");
        bullet("service/ — only knows business rules. No HTTP details (no Request/Response objects).");
        bullet("controller/ — only knows HTTP. Delegates all logic to services.");
        bullet("dto/ — prevents leaking internal entity fields (e.g., password hash) to the browser.");
        para("This separation makes the code easier to test, change, and understand. "
           + "You can swap the database without touching controllers. "
           + "You can add a new endpoint without touching business logic.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 4 — Entry Point
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection4() throws IOException {
        newPage();
        sectionHeading("Section 4: Entry Point", "4");
        fileHeading("OnlineBankingSystemApplication.java");
        codeBlock(new String[]{
            "@SpringBootApplication",
            "public class OnlineBankingSystemApplication {",
            "    public static void main(String[] args) {",
            "        SpringApplication.run(OnlineBankingSystemApplication.class, args);",
            "    }",
            "}"
        });
        explainBlock(new String[]{
            "@SpringBootApplication is a shortcut for three annotations:",
            "  @Configuration     — this class can define Spring beans",
            "  @EnableAutoConfiguration — auto-configure based on classpath",
            "  @ComponentScan     — scan this package and sub-packages for components",
            "",
            "SpringApplication.run(...) does all of this:",
            "  1. Creates the Spring application context",
            "  2. Scans all @Component, @Service, @Repository, @Controller classes",
            "  3. Reads application.properties",
            "  4. Sets up the database connection pool",
            "  5. Starts the embedded Tomcat server on port 8080",
            "  6. Registers all @RequestMapping endpoints"
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 5 — Data Models
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection5() throws IOException {
        newPage();
        sectionHeading("Section 5: Data Models (model/)", "5");
        para("Models are Java classes that map directly to database tables. "
           + "JPA (Java Persistence API) reads the annotations and creates/updates the tables automatically. "
           + "Lombok annotations reduce boilerplate by generating getters, setters, and constructors at compile time.");

        // ── User.java ──
        subHeading("5.1  User.java");
        codeBlock(new String[]{
            "@Entity",
            "@Table(name = \"users\")"
        });
        explainBlock(new String[]{
            "@Entity  — tells JPA 'this class maps to a database table'.",
            "@Table(name = \"users\")  — names the table 'users' in PostgreSQL.",
            "Without @Table, JPA would use the class name ('user') as the table name."
        });

        codeBlock(new String[]{
            "@Data @NoArgsConstructor @AllArgsConstructor"
        });
        explainBlock(new String[]{
            "These are Lombok annotations. Lombok generates code at compile time:",
            "  @Data            — generates getters, setters, equals(), hashCode(), toString()",
            "  @NoArgsConstructor — generates public User() {}",
            "  @AllArgsConstructor — generates public User(id, username, password, ...) {}"
        });

        codeBlock(new String[]{
            "@Id",
            "@GeneratedValue(strategy = GenerationType.IDENTITY)",
            "private Long id;"
        });
        explainBlock(new String[]{
            "@Id  — marks this field as the primary key.",
            "@GeneratedValue(IDENTITY)  — the database auto-increments this (1, 2, 3...).",
            "You never set 'id' manually; the database assigns it on INSERT."
        });

        codeBlock(new String[]{
            "@Column(nullable = false, unique = true)",
            "private String username;"
        });
        explainBlock(new String[]{
            "nullable = false  — this column cannot be NULL in the database.",
            "unique = true     — no two rows can have the same username.",
            "If you try to save a duplicate username, the database throws a constraint violation."
        });

        ensureSpace(120);
        codeBlock(new String[]{
            "@Column",
            "private LocalDateTime createdAt;",
            "",
            "@PrePersist",
            "protected void onCreate() {",
            "    if (createdAt == null) createdAt = LocalDateTime.now();",
            "}"
        });
        explainBlock(new String[]{
            "@PrePersist  — a JPA lifecycle hook. This method runs automatically",
            "just before a new User row is INSERTed into the database.",
            "It sets the creation timestamp so you never forget to set it manually."
        });

        ensureSpace(160);
        codeBlock(new String[]{
            "@ElementCollection(fetch = FetchType.EAGER)",
            "@CollectionTable(name = \"user_roles\",",
            "    joinColumns = @JoinColumn(name = \"user_id\"))",
            "@Column(name = \"role\")",
            "private Set<String> roles = new HashSet<>();"
        });
        explainBlock(new String[]{
            "@ElementCollection  — stores a collection of simple values in a separate table.",
            "@CollectionTable    — names that table 'user_roles' with a 'user_id' foreign key.",
            "FetchType.EAGER     — roles are loaded immediately when the User is loaded.",
            "                      (needed because security checks happen right after loading)",
            "Each user has roles like 'ROLE_USER' or 'ROLE_ADMIN'."
        });

        ensureSpace(200);
        codeBlock(new String[]{
            "public class User implements UserDetails {",
            "    @Override",
            "    public Collection<? extends GrantedAuthority> getAuthorities() {",
            "        return roles.stream()",
            "            .map(SimpleGrantedAuthority::new)",
            "            .collect(Collectors.toList());",
            "    }",
            "    @Override public boolean isAccountNonExpired()     { return true; }",
            "    @Override public boolean isAccountNonLocked()      { return true; }",
            "    @Override public boolean isCredentialsNonExpired() { return true; }",
            "    @Override public boolean isEnabled()               { return true; }",
            "}"
        });
        explainBlock(new String[]{
            "UserDetails is a Spring Security interface. By implementing it, our User class",
            "can be used directly by Spring Security for authentication.",
            "getAuthorities() converts our role strings (\"ROLE_USER\") into Spring Security's",
            "GrantedAuthority objects. The other methods return true — we don't lock accounts."
        });

        // ── Account.java ──
        newPage();
        subHeading("5.2  Account.java");
        codeBlock(new String[]{
            "@ManyToOne(fetch = FetchType.LAZY)",
            "@JoinColumn(name = \"user_id\", nullable = false)",
            "private User owner;"
        });
        explainBlock(new String[]{
            "@ManyToOne  — many accounts can belong to one user.",
            "FetchType.LAZY  — the User object is only loaded from the database when you",
            "                  actually call account.getOwner(). Saves memory and queries.",
            "@JoinColumn — creates a 'user_id' foreign key column in the accounts table."
        });

        codeBlock(new String[]{
            "@Enumerated(EnumType.STRING)",
            "private AccountType accountType;",
            "",
            "public enum AccountType { SAVINGS, CHECKING }"
        });
        explainBlock(new String[]{
            "@Enumerated(STRING)  — stores the enum as text ('SAVINGS' or 'CHECKING')",
            "in the database instead of a number (0 or 1).",
            "Using STRING is safer: if you reorder the enum values, the data stays correct."
        });

        codeBlock(new String[]{
            "@PrePersist",
            "protected void onCreate() {",
            "    createdAt = LocalDateTime.now();",
            "    updatedAt = LocalDateTime.now();",
            "    if (balance == null) balance = BigDecimal.ZERO;",
            "    if (accountType == null) accountType = AccountType.SAVINGS;",
            "}",
            "@PreUpdate",
            "protected void onUpdate() { updatedAt = LocalDateTime.now(); }"
        });
        explainBlock(new String[]{
            "@PrePersist  — runs before INSERT. Sets initial timestamps and defaults.",
            "@PreUpdate   — runs before UPDATE. Keeps updatedAt current automatically.",
            "BigDecimal.ZERO  — new accounts start with a zero balance.",
            "Never use double or float for money — floating point errors cause cents to vanish."
        });

        // ── Transaction.java ──
        subHeading("5.3  Transaction.java");
        codeBlock(new String[]{
            "@ManyToOne(fetch = FetchType.LAZY)",
            "@JoinColumn(name = \"from_account_id\")",
            "private Account fromAccount;  // nullable for DEPOSIT",
            "",
            "@ManyToOne(fetch = FetchType.LAZY)",
            "@JoinColumn(name = \"to_account_id\", nullable = false)",
            "private Account toAccount;"
        });
        explainBlock(new String[]{
            "A transaction links two accounts.",
            "fromAccount can be null for DEPOSIT (money comes from outside the system).",
            "toAccount is always required — money must go somewhere.",
            "Both use LAZY loading to avoid loading full account graphs unnecessarily."
        });

        codeBlock(new String[]{
            "public enum TransactionType { TRANSFER, DEPOSIT, WITHDRAWAL }"
        });
        explainBlock(new String[]{
            "TRANSFER  — moves money from one account to another.",
            "DEPOSIT   — adds money to an account (fromAccount is null).",
            "WITHDRAWAL — removes money from an account (toAccount may be a holding account)."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 6 — Security
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection6() throws IOException {
        newPage();
        sectionHeading("Section 6: Security Layer (security/)", "6");
        subHeading("What is a Security Filter Chain?");
        para("Every HTTP request passes through a chain of filters before reaching your controller. "
           + "Think of it like airport security — each checkpoint checks something different. "
           + "Spring Security adds its own filters. Our custom JwtRequestFilter is added to this chain.");

        // SecurityConfig
        fileHeading("SecurityConfig.java");
        codeBlock(new String[]{
            "@Configuration",
            "@EnableWebSecurity",
            "@EnableMethodSecurity(prePostEnabled = true)"
        });
        explainBlock(new String[]{
            "@Configuration       — this class defines Spring beans (methods annotated @Bean).",
            "@EnableWebSecurity   — activates Spring Security's web security support.",
            "@EnableMethodSecurity — allows @PreAuthorize annotations on individual methods,",
            "                       e.g., @PreAuthorize(\"isAuthenticated()\") on a controller."
        });

        codeBlock(new String[]{
            "@Bean",
            "public PasswordEncoder passwordEncoder() {",
            "    return new BCryptPasswordEncoder();",
            "}"
        });
        explainBlock(new String[]{
            "BCrypt is a one-way hashing algorithm designed for passwords.",
            "When a user registers, their password is hashed before saving to the database.",
            "When they log in, the entered password is hashed and compared to the stored hash.",
            "The original password is NEVER stored — even database admins can't see it.",
            "BCrypt also adds a random 'salt' so two identical passwords produce different hashes."
        });

        ensureSpace(100);
        codeBlock(new String[]{
            ".csrf(csrf -> csrf.disable())"
        });
        explainBlock(new String[]{
            "CSRF (Cross-Site Request Forgery) protection is disabled because we use JWT tokens",
            "instead of browser cookies. CSRF attacks exploit cookies — since we don't use",
            "cookies for authentication, CSRF protection is unnecessary here."
        });

        codeBlock(new String[]{
            ".authorizeHttpRequests(authz -> authz",
            "    .requestMatchers(\"/landing.html\", \"/*.js\", \"/*.css\").permitAll()",
            "    .requestMatchers(\"/api/auth/**\").permitAll()",
            "    .anyRequest().authenticated()",
            ")"
        });
        explainBlock(new String[]{
            "This defines who can access what URLs:",
            "  permitAll()     — anyone can access (no JWT needed)",
            "  authenticated() — must have a valid JWT token",
            "Static files (HTML, JS, CSS) are public so the login page loads.",
            "/api/auth/** is public so users can register and log in.",
            "Everything else requires authentication."
        });

        ensureSpace(120);
        codeBlock(new String[]{
            ".sessionManagement(session -> session",
            "    .sessionCreationPolicy(SessionCreationPolicy.STATELESS)",
            ")"
        });
        explainBlock(new String[]{
            "STATELESS means the server never creates an HTTP session.",
            "Every request must include the JWT token — the server doesn't 'remember' you.",
            "This is ideal for REST APIs and scales horizontally (any server can handle any request)."
        });

        codeBlock(new String[]{
            "http.addFilterBefore(jwtRequestFilter,",
            "    UsernamePasswordAuthenticationFilter.class);"
        });
        explainBlock(new String[]{
            "Our custom JWT filter runs BEFORE Spring's default username/password filter.",
            "This means JWT authentication is checked first on every request.",
            "If the JWT is valid, the user is authenticated before any other filter runs."
        });

        // JwtUtil
        newPage();
        fileHeading("JwtUtil.java");
        codeBlock(new String[]{
            "@Value(\"${jwt.secret}\")",
            "private String secret;",
            "@Value(\"${jwt.expiration.ms}\")",
            "private long expirationMs;"
        });
        explainBlock(new String[]{
            "@Value reads values from application.properties at startup.",
            "jwt.secret  — the secret key used to sign tokens (keep this private!).",
            "jwt.expiration.ms = 86400000 = 24 hours (86400 seconds x 1000 milliseconds)."
        });

        codeBlock(new String[]{
            "@PostConstruct",
            "public void init() {",
            "    if (secret == null || secret.length() < 64) {",
            "        this.key = Keys.secretKeyFor(SignatureAlgorithm.HS512);",
            "    } else {",
            "        this.key = Keys.hmacShaKeyFor(secret.getBytes());",
            "    }",
            "}"
        });
        explainBlock(new String[]{
            "@PostConstruct runs after the bean is created and @Value fields are injected.",
            "HS512 requires a key of at least 512 bits (64 bytes).",
            "If the configured secret is too short, a random key is generated.",
            "WARNING: a random key means tokens won't survive server restarts.",
            "In production, always configure a long, stable secret in application.properties."
        });

        codeBlock(new String[]{
            "public String generateToken(UserDetails userDetails) {",
            "    return Jwts.builder()",
            "        .setSubject(userDetails.getUsername())",
            "        .setIssuedAt(new Date())",
            "        .setExpiration(new Date(System.currentTimeMillis() + expirationMs))",
            "        .signWith(key, SignatureAlgorithm.HS512)",
            "        .compact();",
            "}"
        });
        explainBlock(new String[]{
            "Builds a JWT token step by step:",
            "  setSubject    — stores the username inside the token payload.",
            "  setIssuedAt   — records when the token was created.",
            "  setExpiration — token expires after 24 hours.",
            "  signWith      — adds a cryptographic signature using HS512.",
            "  compact()     — serializes to the final Base64-encoded string."
        });

        codeBlock(new String[]{
            "public Boolean validateToken(String token, UserDetails userDetails) {",
            "    final String username = extractUsername(token);",
            "    return (username.equals(userDetails.getUsername())",
            "            && !isTokenExpired(token));",
            "}"
        });
        explainBlock(new String[]{
            "Validates two things:",
            "  1. The username in the token matches the user we loaded from the database.",
            "  2. The token has not expired.",
            "The signature is verified automatically when parsing — if tampered, parsing throws."
        });

        // JwtRequestFilter
        newPage();
        fileHeading("JwtRequestFilter.java");
        codeBlock(new String[]{
            "public class JwtRequestFilter extends OncePerRequestFilter {"
        });
        explainBlock(new String[]{
            "OncePerRequestFilter guarantees this filter runs exactly once per HTTP request.",
            "Without this, some filter chains could invoke the filter multiple times."
        });

        codeBlock(new String[]{
            "final String authorizationHeader = request.getHeader(\"Authorization\");",
            "if (authorizationHeader != null",
            "        && authorizationHeader.startsWith(\"Bearer \")) {",
            "    jwt = authorizationHeader.substring(7);",
            "    username = jwtUtil.extractUsername(jwt);",
            "}"
        });
        explainBlock(new String[]{
            "Reads the Authorization header from the HTTP request.",
            "A valid header looks like:  Authorization: Bearer eyJhbGci...",
            "We strip 'Bearer ' (7 characters) to get just the token string.",
            "Then we extract the username from the token's payload."
        });

        codeBlock(new String[]{
            "if (username != null &&",
            "    SecurityContextHolder.getContext().getAuthentication() == null) {",
            "    UserDetails userDetails =",
            "        userDetailsService.loadUserByUsername(username);",
            "    if (jwtUtil.validateToken(jwt, userDetails)) {",
            "        UsernamePasswordAuthenticationToken authToken =",
            "            new UsernamePasswordAuthenticationToken(",
            "                userDetails, null, userDetails.getAuthorities());",
            "        SecurityContextHolder.getContext().setAuthentication(authToken);",
            "    }",
            "}",
            "chain.doFilter(request, response);"
        });
        explainBlock(new String[]{
            "If the token is valid, we create an authentication object and store it in",
            "SecurityContextHolder — this is how Spring Security knows the user is logged in",
            "for this request thread.",
            "chain.doFilter() passes the request to the next filter or the controller.",
            "If the token is invalid or missing, no authentication is set and the request",
            "will be rejected by the security rules defined in SecurityConfig."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 7 — Services
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection7() throws IOException {
        newPage();
        sectionHeading("Section 7: Service Layer (service/)", "7");
        subHeading("What is a Service Layer?");
        para("Controllers receive HTTP requests. Models define data. Services contain the actual "
           + "business logic — the rules of what the app does. This separation keeps code organized "
           + "and testable. You can unit-test a service without starting a web server.");

        // AuthService
        fileHeading("AuthService.java");
        codeBlock(new String[]{
            "@Transactional",
            "public User registerUser(UserRegistrationDto registrationDto) {",
            "    if (userRepository.existsByUsername(registrationDto.getUsername())) {",
            "        throw new IllegalArgumentException(\"Username already exists\");",
            "    }",
            "    newUser.setPassword(",
            "        passwordEncoder.encode(registrationDto.getPassword()));",
            "    newUser.setRoles(Set.of(\"ROLE_USER\"));",
            "    return userRepository.save(newUser);",
            "}"
        });
        explainBlock(new String[]{
            "@Transactional — if anything fails inside this method, the entire database",
            "operation is rolled back. No partial saves.",
            "Steps:",
            "  1. Check if username already exists — throw if duplicate.",
            "  2. Hash the password with BCrypt before saving.",
            "  3. Assign the default role 'ROLE_USER'.",
            "  4. Save the user to the database and return the saved entity."
        });

        codeBlock(new String[]{
            "public AuthenticationResponseDto authenticateUser(",
            "        AuthenticationRequestDto authRequest) {",
            "    authenticationManager.authenticate(",
            "        new UsernamePasswordAuthenticationToken(",
            "            authRequest.getUsername(), authRequest.getPassword()));",
            "    UserDetails userDetails =",
            "        userDetailsService.loadUserByUsername(authRequest.getUsername());",
            "    String jwt = jwtUtil.generateToken(userDetails);",
            "    return new AuthenticationResponseDto(jwt);",
            "}"
        });
        explainBlock(new String[]{
            "authenticationManager.authenticate() checks the username and password.",
            "If wrong, it throws BadCredentialsException (Spring Security handles the 401).",
            "If correct, we load the full UserDetails, generate a JWT, and return it.",
            "The client stores this JWT and sends it with every future request."
        });

        // TransactionService
        newPage();
        fileHeading("TransactionService.java");
        codeBlock(new String[]{
            "private Account findAndVerifyOwnership(",
            "        String accountNumber, String username) {",
            "    Account account = accountRepository",
            "        .findByAccountNumber(accountNumber)",
            "        .orElseThrow(() -> new IllegalArgumentException(",
            "            \"Account not found: \" + accountNumber));",
            "    if (!account.getOwner().getUsername().equals(username)) {",
            "        throw new SecurityException(",
            "            \"User does not own this account.\");",
            "    }",
            "    return account;",
            "}"
        });
        explainBlock(new String[]{
            "A helper method reused by deposit, withdrawal, and transfer.",
            "orElseThrow() — if the account doesn't exist, throw immediately (fail fast).",
            "Ownership check — verifies the logged-in user actually owns this account.",
            "This prevents users from transferring money out of other people's accounts."
        });

        codeBlock(new String[]{
            "@Transactional",
            "public TransactionDto transferFunds(",
            "        TransferRequestDto request, String username) {",
            "    // 1. Find both accounts",
            "    // 2. Verify ownership of source account",
            "    // 3. Check sufficient funds: from.balance >= amount",
            "    // 4. Debit source:      from.balance -= amount",
            "    // 5. Credit destination: to.balance  += amount",
            "    // 6. Save both accounts",
            "    // 7. Create Transaction record",
            "    // 8. Return DTO",
            "}"
        });
        explainBlock(new String[]{
            "@Transactional is critical here. If step 5 fails after step 4, the database",
            "rolls back — money is not lost. Both debit and credit succeed or both fail.",
            "BigDecimal is used for all money arithmetic.",
            "NEVER use double or float for money — floating point errors cause cents to vanish.",
            "Example: 0.1 + 0.2 = 0.30000000000000004 in floating point arithmetic."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 8 — Controllers
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection8() throws IOException {
        newPage();
        sectionHeading("Section 8: Controllers (controller/)", "8");
        subHeading("What is a REST Controller?");
        para("A controller maps URLs to Java methods. When the browser calls POST /api/auth/login, "
           + "Spring finds the method annotated with @PostMapping(\"/login\") and runs it. "
           + "ResponseEntity lets you control the HTTP status code returned (200 OK, 400 Bad Request, etc.).");

        // AuthController
        fileHeading("AuthController.java");
        codeBlock(new String[]{
            "@RestController",
            "@RequestMapping(\"/api/auth\")"
        });
        explainBlock(new String[]{
            "@RestController — a controller that returns JSON (not HTML pages).",
            "                  Combines @Controller + @ResponseBody.",
            "@RequestMapping(\"/api/auth\") — all endpoints in this class start with /api/auth.",
            "So @PostMapping(\"/login\") becomes POST /api/auth/login."
        });

        codeBlock(new String[]{
            "@PostMapping(\"/register\")",
            "public ResponseEntity<?> registerUser(",
            "        @Valid @RequestBody UserRegistrationDto registrationDto) {"
        });
        explainBlock(new String[]{
            "@PostMapping — handles HTTP POST requests to /api/auth/register.",
            "@RequestBody — reads the JSON from the request body and converts it to a DTO.",
            "@Valid — triggers Bean Validation: checks @NotBlank, @Size, @Email annotations",
            "         on the DTO fields. If validation fails, Spring returns 400 Bad Request."
        });

        // TransactionController
        newPage();
        fileHeading("TransactionController.java");
        codeBlock(new String[]{
            "@RestController",
            "@RequestMapping(\"/api/transactions\")",
            "@PreAuthorize(\"isAuthenticated()\")",
            "public class TransactionController {"
        });
        explainBlock(new String[]{
            "@PreAuthorize(\"isAuthenticated()\") on the class means ALL endpoints require",
            "a valid JWT. No need to repeat it on every method.",
            "If the JWT is missing or invalid, Spring Security returns 401 Unauthorized."
        });

        codeBlock(new String[]{
            "private String currentUser() {",
            "    return SecurityContextHolder.getContext()",
            "        .getAuthentication().getName();",
            "}"
        });
        explainBlock(new String[]{
            "Helper method to get the logged-in username.",
            "SecurityContextHolder stores the current user's authentication for this thread.",
            "JwtRequestFilter put it there earlier in the request lifecycle.",
            ".getName() returns the username (the 'subject' from the JWT payload)."
        });

        codeBlock(new String[]{
            "private ResponseEntity<byte[]> pdfResponse(",
            "        byte[] pdf, String filename) {",
            "    HttpHeaders headers = new HttpHeaders();",
            "    headers.setContentType(MediaType.APPLICATION_PDF);",
            "    headers.setContentDispositionFormData(\"attachment\", filename);",
            "    return new ResponseEntity<>(pdf, headers, HttpStatus.OK);",
            "}"
        });
        explainBlock(new String[]{
            "Helper to build a PDF download response.",
            "Content-Type: application/pdf — tells the browser this is a PDF.",
            "Content-Disposition: attachment — tells the browser to download the file",
            "                                  instead of trying to display it inline.",
            "The PDF bytes are sent directly in the response body."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 9 — ReceiptService / PDFBox
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection9() throws IOException {
        newPage();
        sectionHeading("Section 9: Receipt & PDF Generation (ReceiptService.java)", "9");
        subHeading("What is PDFBox?");
        para("Apache PDFBox is a Java library for creating and reading PDF files. "
           + "SecureBank uses it to generate transaction receipts and history reports "
           + "that users can download directly from the browser.");

        subHeading("Key PDFBox concepts:");
        codeBlock(new String[]{
            "PDDocument doc = new PDDocument();        // The PDF file",
            "PDPage page = new PDPage(PDRectangle.A4); // A4 page (210x297mm)",
            "doc.addPage(page);",
            "PDPageContentStream stream =              // Pen to draw on the page",
            "    new PDPageContentStream(doc, page);"
        });
        explainBlock(new String[]{
            "PDDocument  — the entire PDF file in memory.",
            "PDPage      — a single page. A4 is 595 x 842 points (1 point = 1/72 inch).",
            "PDPageContentStream — the drawing surface. You write text and shapes through it.",
            "Think of PDDocument as a blank book, PDPage as a blank page,",
            "and PDPageContentStream as a pen to write on that page."
        });

        codeBlock(new String[]{
            "stream.beginText();",
            "stream.setFont(boldFont, 18);",
            "stream.newLineAtOffset(50, 750); // x=50 from left, y=750 from bottom",
            "stream.showText(\"SecureBank - Transaction Receipt\");",
            "stream.endText();"
        });
        explainBlock(new String[]{
            "PDF coordinates start from the BOTTOM-LEFT corner of the page.",
            "y=750 is near the top of an A4 page (which is 842 points tall).",
            "x=50 is 50 points from the left edge.",
            "Always call beginText() before writing text and endText() after.",
            "setFont() must be called before showText() — there is no default font."
        });

        codeBlock(new String[]{
            "ByteArrayOutputStream out = new ByteArrayOutputStream();",
            "doc.save(out);",
            "doc.close();",
            "return out.toByteArray();"
        });
        explainBlock(new String[]{
            "Instead of saving to a file on disk, we save to memory (ByteArrayOutputStream).",
            "The bytes are then returned to the controller, which sends them to the browser.",
            "Always call doc.close() to release resources and finalize the PDF structure.",
            "The browser receives the bytes and triggers a file download."
        });

        subHeading("Drawing shapes (used for colored backgrounds):");
        codeBlock(new String[]{
            "stream.setNonStrokingColor(0.95f, 0.95f, 0.95f); // light gray",
            "stream.addRect(x, y, width, height);",
            "stream.fill();"
        });
        explainBlock(new String[]{
            "setNonStrokingColor sets the fill color (RGB values 0.0 to 1.0).",
            "addRect defines a rectangle. fill() paints it with the current fill color.",
            "This is how code block backgrounds and header bars are drawn."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 10 — Frontend
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection10() throws IOException {
        newPage();
        sectionHeading("Section 10: Frontend (shared.js)", "10");
        subHeading("What is sessionStorage?");
        para("sessionStorage is a browser storage that holds data only while the tab is open. "
           + "When you close the tab, everything in sessionStorage is deleted. "
           + "We use it to store the JWT token — so closing the browser automatically logs you out.");

        codeBlock(new String[]{
            "function getJwt()   { return sessionStorage.getItem('jwtToken'); }",
            "function setJwt(t)  { sessionStorage.setItem('jwtToken', t); }",
            "function clearJwt() { sessionStorage.removeItem('jwtToken'); }"
        });
        explainBlock(new String[]{
            "Simple helpers to read, write, and delete the JWT from sessionStorage.",
            "All API calls use getJwt() to attach the token to the Authorization header.",
            "Logout calls clearJwt() to remove the token — the user is immediately logged out."
        });

        codeBlock(new String[]{
            "async function apiRequest(endpoint, method = 'GET',",
            "                          body = null, requiresAuth = true) {",
            "    const headers = { 'Content-Type': 'application/json' };",
            "    if (requiresAuth) {",
            "        const token = getJwt();",
            "        if (token) headers['Authorization'] = 'Bearer ' + token;",
            "    }",
            "    const options = { method, headers };",
            "    if (body !== null) options.body = JSON.stringify(body);",
            "    return await fetch(API_BASE_URL + endpoint, options);",
            "}"
        });
        explainBlock(new String[]{
            "Central function for all API calls — every page uses this instead of raw fetch().",
            "fetch() is the browser's built-in HTTP client.",
            "async/await makes asynchronous code look synchronous and easier to read.",
            "Every authenticated request automatically includes the JWT in the Authorization header.",
            "JSON.stringify(body) converts a JavaScript object to a JSON string for the request body."
        });

        codeBlock(new String[]{
            "function startInactivityTimer() {",
            "    ['mousemove','keydown','mousedown',",
            "     'touchstart','scroll','click'].forEach(evt =>",
            "        document.addEventListener(evt,",
            "            _resetInactivityTimer, { passive: true })",
            "    );",
            "    _resetInactivityTimer();",
            "}"
        });
        explainBlock(new String[]{
            "Listens for any user activity (mouse, keyboard, touch, scroll).",
            "If no activity for 5 minutes, the user is automatically logged out.",
            "passive: true improves scroll performance — tells the browser this listener",
            "         won't call preventDefault(), so scrolling doesn't need to wait for it.",
            "This is a security feature: unattended sessions are closed automatically."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SECTION 11 — application.properties
    // ══════════════════════════════════════════════════════════════════════════
    private void buildSection11() throws IOException {
        newPage();
        sectionHeading("Section 11: application.properties", "11");
        para("This file configures the entire application. Spring Boot reads it at startup. "
           + "You can override any value with environment variables or command-line arguments.");

        codeBlock(new String[]{
            "spring.datasource.url=jdbc:postgresql://localhost:5432/online_banking_db",
            "spring.datasource.username=postuser",
            "spring.datasource.password=12345",
            "spring.datasource.driver-class-name=org.postgresql.Driver"
        });
        explainBlock(new String[]{
            "Configures the PostgreSQL database connection.",
            "jdbc:postgresql://localhost:5432/online_banking_db",
            "  localhost  — database is on the same machine",
            "  5432       — default PostgreSQL port",
            "  online_banking_db — the database name",
            "In production, never hardcode passwords here — use environment variables."
        });

        codeBlock(new String[]{
            "spring.jpa.hibernate.ddl-auto=update"
        });
        explainBlock(new String[]{
            "ddl-auto=update means Hibernate automatically creates or updates database tables",
            "based on your @Entity classes. You don't write SQL CREATE TABLE statements.",
            "Options:",
            "  create       — drop and recreate tables on every startup (loses data!)",
            "  create-drop  — create on startup, drop on shutdown",
            "  update       — add missing columns/tables, never drop (safe for development)",
            "  validate     — check schema matches entities, fail if not (good for production)",
            "  none         — do nothing (you manage the schema yourself)"
        });

        codeBlock(new String[]{
            "jwt.secret=SecureBankVeryLongSecretKeyForJWT...",
            "jwt.expiration.ms=86400000"
        });
        explainBlock(new String[]{
            "jwt.secret — the key used to sign and verify JWT tokens.",
            "             Must be at least 64 characters for HS512.",
            "             Keep this secret! Anyone with this key can forge tokens.",
            "jwt.expiration.ms = 86400000 = 24 hours",
            "  Calculation: 24 hours x 60 min x 60 sec x 1000 ms = 86,400,000 ms"
        });

        codeBlock(new String[]{
            "server.port=8080",
            "spring.jpa.show-sql=true",
            "logging.level.org.springframework.security=DEBUG"
        });
        explainBlock(new String[]{
            "server.port=8080 — the app listens on http://localhost:8080.",
            "spring.jpa.show-sql=true — prints every SQL query to the console (useful for debugging).",
            "logging.level...=DEBUG — shows detailed Spring Security logs (helpful when debugging auth).",
            "In production, set show-sql=false and logging level to WARN or ERROR."
        });
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  PDF RENDERING HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    /** Open a new page, set up content stream, reset cursor. */
    private void newPage() throws IOException {
        closeCurrentPage();
        currentPage = new PDPage(PDRectangle.A4);
        doc.addPage(currentPage);
        pageNumber++;
        cs = new PDPageContentStream(doc, currentPage);
        cursorY = PAGE_H - MARGIN;
        drawPageNumber();
    }

    /** Close the current content stream if open. */
    private void closeCurrentPage() throws IOException {
        if (cs != null) {
            cs.close();
            cs = null;
        }
    }

    /** Draw page number at the bottom of the current page. */
    private void drawPageNumber() throws IOException {
        String pn = String.valueOf(pageNumber);
        float w = textWidth(pn, FONT_REGULAR, 10);
        drawText(pn, FONT_REGULAR, 10, new Color(0x99, 0x99, 0x99),
                 (PAGE_W - w) / 2, 25);
    }

    /** Ensure there is at least `needed` points of vertical space; start new page if not. */
    private void ensureSpace(float needed) throws IOException {
        if (cursorY - needed < MARGIN + 30) {
            newPage();
        }
    }

    // ── Section / heading helpers ──────────────────────────────────────────

    private void sectionHeading(String title, String sectionNum) throws IOException {
        ensureSpace(60);
        // Blue bar
        fillRect(MARGIN - 5, cursorY - 22, CONTENT_W + 10, 32, BLUE_HEADER);
        drawText(title, FONT_BOLD, 15, WHITE, MARGIN + 2, cursorY - 14);
        cursorY -= 42;
        if (sectionNum != null) {
            tocEntries.add(new String[]{title, String.valueOf(pageNumber)});
        }
    }

    private void subHeading(String title) throws IOException {
        ensureSpace(40);
        cursorY -= 8;
        drawText(title, FONT_BOLD, 12, BLUE_HEADER, MARGIN, cursorY);
        cursorY -= 18;
    }

    private void fileHeading(String filename) throws IOException {
        ensureSpace(40);
        cursorY -= 6;
        fillRect(MARGIN, cursorY - 16, CONTENT_W, 24, BLUE_LIGHT);
        drawRect(MARGIN, cursorY - 16, CONTENT_W, 24, BLUE_HEADER, 0.5f);
        drawText(filename, FONT_BOLD, 12, BLUE_HEADER, MARGIN + 6, cursorY - 10);
        cursorY -= 30;
    }

    // ── Text helpers ───────────────────────────────────────────────────────

    /** Wrapped paragraph text. */
    private void para(String text) throws IOException {
        ensureSpace(30);
        cursorY -= 4;
        List<String> lines = wrapText(text, FONT_REGULAR, 11, CONTENT_W);
        for (String line : lines) {
            ensureSpace(16);
            drawText(line, FONT_REGULAR, 11, GRAY_TEXT, MARGIN, cursorY);
            cursorY -= 16;
        }
        cursorY -= 4;
    }

    /** Bullet point. */
    private void bullet(String text) throws IOException {
        ensureSpace(16);
        List<String> lines = wrapText(text, FONT_REGULAR, 11, CONTENT_W - 16);
        boolean first = true;
        for (String line : lines) {
            ensureSpace(16);
            if (first) {
                drawText("\u2022", FONT_REGULAR, 11, BLUE_HEADER, MARGIN + 4, cursorY);
                first = false;
            }
            drawText(line, FONT_REGULAR, 11, GRAY_TEXT, MARGIN + 16, cursorY);
            cursorY -= 16;
        }
    }

    /** Code block with gray background. */
    private void codeBlock(String[] lines) throws IOException {
        float lineH = 14f;
        float padding = 8f;
        float blockH = lines.length * lineH + padding * 2;
        ensureSpace(blockH + 10);
        cursorY -= 6;
        fillRect(MARGIN, cursorY - blockH + padding, CONTENT_W, blockH, GRAY_CODE_BG);
        drawRect(MARGIN, cursorY - blockH + padding, CONTENT_W, blockH, new Color(0xCC, 0xCC, 0xCC), 0.5f);
        float ty = cursorY - padding - lineH + 4;
        for (String line : lines) {
            List<String> wrapped = wrapText(line, FONT_MONO, 9, CONTENT_W - 16);
            for (String wl : wrapped) {
                drawText(wl, FONT_MONO, 9, new Color(0x1A, 0x1A, 0x6E), MARGIN + 8, ty);
                ty -= lineH;
            }
        }
        cursorY = ty - padding + 2;
        cursorY -= 6;
    }

    /** Explanation block with light blue background. */
    private void explainBlock(String[] lines) throws IOException {
        float lineH = 14f;
        float padding = 8f;
        float blockH = lines.length * lineH + padding * 2;
        ensureSpace(blockH + 10);
        cursorY -= 4;
        fillRect(MARGIN, cursorY - blockH + padding, CONTENT_W, blockH, BLUE_LIGHT);
        drawRect(MARGIN, cursorY - blockH + padding, CONTENT_W, blockH, BLUE_HEADER, 0.5f);
        // Arrow label
        drawText("\u2192 Explanation", FONT_BOLD, 9, BLUE_HEADER, MARGIN + 6, cursorY - 4);
        float ty = cursorY - padding - lineH + 2;
        for (String line : lines) {
            List<String> wrapped = wrapText(line, FONT_REGULAR, 10, CONTENT_W - 16);
            for (String wl : wrapped) {
                drawText(wl, FONT_REGULAR, 10, GRAY_TEXT, MARGIN + 8, ty);
                ty -= lineH;
            }
        }
        cursorY = ty - padding + 2;
        cursorY -= 8;
    }

    // ── Low-level drawing ──────────────────────────────────────────────────

    private void drawText(String text, PDType1Font font, float size, Color color, float x, float y)
            throws IOException {
        cs.beginText();
        cs.setFont(font, size);
        setColor(color, true);  // text uses non-stroking (fill) color
        cs.newLineAtOffset(x, y);
        cs.showText(sanitize(text));
        cs.endText();
    }

    private void drawCenteredText(String text, PDType1Font font, float size, Color color, float y)
            throws IOException {
        float w = textWidth(text, font, size);
        drawText(text, font, size, color, (PAGE_W - w) / 2f, y);
    }

    private void fillRect(float x, float y, float w, float h, Color color) throws IOException {
        setColor(color, true);
        cs.addRect(x, y, w, h);
        cs.fill();
    }

    private void drawRect(float x, float y, float w, float h, Color color, float lineWidth)
            throws IOException {
        cs.setLineWidth(lineWidth);
        setColor(color, false);
        cs.addRect(x, y, w, h);
        cs.stroke();
    }

    private void drawDots(float x1, float x2, float y) throws IOException {
        cs.beginText();
        cs.setFont(FONT_REGULAR, 10);
        setColor(new Color(0xBB, 0xBB, 0xBB), true);  // non-stroking for text
        float dotW = textWidth(".", FONT_REGULAR, 10) + 1;
        float cx = x1;
        while (cx + dotW < x2) {
            cs.newLineAtOffset(cx, y);
            cs.showText(".");
            cs.endText();
            cs.beginText();
            cx += dotW + 1;
        }
        cs.endText();
    }

    private void setColor(Color c, boolean fill) throws IOException {
        float r = c.getRed()   / 255f;
        float g = c.getGreen() / 255f;
        float b = c.getBlue()  / 255f;
        if (fill) cs.setNonStrokingColor(r, g, b);
        else      cs.setStrokingColor(r, g, b);
    }

    // ── Text utilities ─────────────────────────────────────────────────────

    private float textWidth(String text, PDType1Font font, float size) {
        try {
            return font.getStringWidth(sanitize(text)) / 1000f * size;
        } catch (IOException e) {
            return text.length() * size * 0.5f;
        }
    }

    private List<String> wrapText(String text, PDType1Font font, float size, float maxWidth) {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) { result.add(""); return result; }
        String[] words = text.split(" ", -1);
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (textWidth(test, font, size) <= maxWidth) {
                line = new StringBuilder(test);
            } else {
                if (line.length() > 0) result.add(line.toString());
                // If single word is too long, just add it
                line = new StringBuilder(word);
            }
        }
        if (line.length() > 0) result.add(line.toString());
        return result;
    }

    /** Replace characters that PDType1Font (Latin-1) can't encode. */
    private String sanitize(String s) {
        if (s == null) return "";
        return s.replace("\u2022", "-")   // bullet
                .replace("\u2192", "->")  // arrow
                .replace("\u2014", "--")  // em dash
                .replace("\u2013", "-")   // en dash
                .replace("\u201C", "\"")  // left quote
                .replace("\u201D", "\"")  // right quote
                .replace("\u2018", "'")   // left single quote
                .replace("\u2019", "'")   // right single quote
                .replaceAll("[^\\x00-\\xFF]", "?");
    }
}
