package com.example.onlinebankingsystem.dto;

import com.example.onlinebankingsystem.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionFilterParams {
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private Transaction.TransactionType type;
    private BigDecimal minAmount;
    private BigDecimal maxAmount;
}
