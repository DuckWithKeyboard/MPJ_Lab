package com.example.onlinebankingsystem.service;

import com.example.onlinebankingsystem.dto.AuthenticationRequestDto;
import com.example.onlinebankingsystem.dto.AuthenticationResponseDto;
import com.example.onlinebankingsystem.dto.UserRegistrationDto;
import com.example.onlinebankingsystem.model.User;
import com.example.onlinebankingsystem.repository.UserRepository;
import com.example.onlinebankingsystem.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
public class AuthService {

    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private AuthenticationManager authenticationManager;
    @Autowired private UserDetailsService userDetailsService;
    @Autowired private JwtUtil jwtUtil;

    // [2FA] Injected OTP service — handles code generation and email sending
    @Autowired private OtpService otpService;

    @Transactional
    public User registerUser(UserRegistrationDto registrationDto) {
        if (userRepository.existsByUsername(registrationDto.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }
        if (userRepository.existsByEmail(registrationDto.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }
        User newUser = new User();
        newUser.setUsername(registrationDto.getUsername());
        newUser.setEmail(registrationDto.getEmail());
        newUser.setPassword(passwordEncoder.encode(registrationDto.getPassword()));
        newUser.setRoles(Set.of("ROLE_USER"));
        return userRepository.save(newUser);
    }

    /**
     * [2FA] STEP 1 of login — verify credentials and send OTP.
     * Previously this returned a JWT directly. Now it sends an OTP email
     * and returns a signal to the frontend to show the OTP input screen.
     * The JWT is only issued after the OTP is verified (see verifyOtpAndLogin).
     */
    public String initiateLogin(AuthenticationRequestDto authRequest) {
        // Verify username and password — throws BadCredentialsException if wrong
        try {
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    authRequest.getUsername(), authRequest.getPassword())
            );
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Incorrect username or password", e);
        }

        // Credentials are correct — load the user to get their email
        User user = userRepository.findByUsername(authRequest.getUsername())
            .orElseThrow(() -> new IllegalStateException("User not found after authentication"));

        // [2FA] Generate a 6-digit OTP and email it to the user
        otpService.generateAndSend(user.getUsername(), user.getEmail());

        // Return a status string — the frontend will show the OTP input screen
        return "OTP_SENT";
    }

    /**
     * [2FA] STEP 2 of login — verify the OTP and issue the JWT.
     * Called from the new /api/auth/verify-otp endpoint.
     */
    public AuthenticationResponseDto verifyOtpAndLogin(String username, String code) {
        // [2FA] Check the OTP code — throws if invalid or expired
        if (!otpService.verify(username, code)) {
            throw new IllegalArgumentException("Invalid or expired OTP code.");
        }

        // OTP is valid — now generate and return the JWT
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
        String jwt = jwtUtil.generateToken(userDetails);
        return new AuthenticationResponseDto(jwt);
    }
}
