package com.example.onlinebankingsystem.service;

// [2FA] Handles OTP generation, storage, email sending, and verification
// Used for both login 2FA and transfer confirmation

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {

    // Thread-safe map: key -> OtpEntry
    // Keys are prefixed: "login:username" or "transfer:username"
    // so login and transfer OTPs never clash with each other
    private final ConcurrentHashMap<String, OtpEntry> otpStore = new ConcurrentHashMap<>();

    private final SecureRandom random = new SecureRandom();

    @Autowired
    private JavaMailSender mailSender;

    @Value("${otp.expiration.ms:300000}")
    private long otpExpirationMs;

    // ── Login OTP ─────────────────────────────────────────────────────────────

    /** Generates and emails a login OTP. @Async = runs on background thread. */
    @Async
    public void generateAndSend(String username, String email) {
        String code = generateCode();
        otpStore.put("login:" + username, new OtpEntry(code, Instant.now().plusMillis(otpExpirationMs)));
        sendEmail(email,
            "SecureBank — Your Login Code",
            "Your SecureBank login verification code is: " + code);
    }

    /** Verifies a login OTP. */
    public boolean verifyLoginOtp(String username, String code) {
        return verifyKey("login:" + username, code);
    }

    // ── Password Reset OTP ────────────────────────────────────────────────────

    /**
     * [FORGOT-PASSWORD] Generates and emails a password reset OTP.
     * Key is prefixed with "reset:email" so it never clashes with login or transfer OTPs.
     */
    @Async
    public void generateAndSendPasswordResetOtp(String email) {
        String code = generateCode();
        otpStore.put("reset:" + email, new OtpEntry(code, Instant.now().plusMillis(otpExpirationMs)));
        sendEmail(email,
            "SecureBank — Password Reset Code",
            "You requested a password reset for your SecureBank account.\n\n" +
            "Your password reset code is: " + code + "\n\n" +
            "If you did not request this, please ignore this email.");
    }

    /** [FORGOT-PASSWORD] Verifies a password reset OTP by email. */
    public boolean verifyPasswordResetOtp(String email, String code) {
        return verifyKey("reset:" + email, code);
    }

    // ── Transfer OTP ──────────────────────────────────────────────────────────
    /**
     * [TRANSFER-OTP] Generates and emails a transfer confirmation OTP.
     * Includes transfer details in the email so the user knows what they're confirming.
     */
    @Async
    public void generateAndSendTransferOtp(String username, String email,
                                            String toAccount, String amount) {
        String code = generateCode();
        otpStore.put("transfer:" + username, new OtpEntry(code, Instant.now().plusMillis(otpExpirationMs)));
        sendEmail(email,
            "SecureBank — Confirm Your Transfer",
            "You are about to transfer $" + amount + " to account " + toAccount + ".\n\n" +
            "Your transfer confirmation code is: " + code + "\n\n" +
            "If you did not initiate this transfer, contact support immediately.");
    }

    /** [TRANSFER-OTP] Verifies a transfer OTP. */
    public boolean verifyTransferOtp(String username, String code) {
        return verifyKey("transfer:" + username, code);
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    private String generateCode() {
        return String.format("%06d", 100000 + random.nextInt(900000));
    }

    private boolean verifyKey(String key, String code) {
        OtpEntry entry = otpStore.get(key);
        if (entry == null) return false;
        if (Instant.now().isAfter(entry.expiresAt())) { otpStore.remove(key); return false; }
        if (!entry.code().equals(code)) return false;
        otpStore.remove(key); // one-time use
        return true;
    }

    // Keep old verify() for backward compatibility with AuthService
    public boolean verify(String username, String code) {
        return verifyLoginOtp(username, code);
    }

    private void sendEmail(String toEmail, String subject, String body) {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(toEmail);
        msg.setSubject(subject);
        msg.setText(body + "\n\nThis code expires in 5 minutes.\n" +
            "If you did not request this, please ignore this email.");
        mailSender.send(msg);
    }

    private record OtpEntry(String code, Instant expiresAt) {}
}
