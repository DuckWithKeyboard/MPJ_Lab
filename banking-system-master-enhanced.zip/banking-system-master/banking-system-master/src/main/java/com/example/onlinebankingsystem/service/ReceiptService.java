package com.example.onlinebankingsystem.service;

import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.repository.AccountRepository;
import com.example.onlinebankingsystem.repository.TransactionRepository;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReceiptService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountRepository accountRepository;

    public byte[] generateReceipt(Long transactionId, String currentUsername) throws Exception {
        // Load transaction
        Transaction transaction = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Transaction not found: " + transactionId));

        // Verify ownership
        boolean ownsFrom = transaction.getFromAccount() != null &&
                currentUsername.equals(transaction.getFromAccount().getOwner().getUsername());
        boolean ownsTo = currentUsername.equals(transaction.getToAccount().getOwner().getUsername());

        if (!ownsFrom && !ownsTo) {
            throw new SecurityException("Access denied to this receipt.");
        }

        // Build PDF
        PDDocument doc = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        doc.addPage(page);

        PDType1Font boldFont = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font regularFont = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

        try (PDPageContentStream stream = new PDPageContentStream(doc, page)) {
            // Header
            stream.beginText();
            stream.setFont(boldFont, 18);
            stream.newLineAtOffset(50, 750);
            stream.showText("SecureBank \u2014 Transaction Receipt");
            stream.endText();

            // Separator line
            stream.moveTo(50, 740);
            stream.lineTo(545, 740);
            stream.stroke();

            // Body fields
            float y = 710;
            float lineHeight = 20;

            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("Transaction ID : " + transaction.getId());
            stream.endText();

            y -= lineHeight;
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("Date & Time    : " + transaction.getTimestamp());
            stream.endText();

            y -= lineHeight;
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("Type           : " + transaction.getType());
            stream.endText();

            y -= lineHeight;
            String fromMasked = transaction.getFromAccount() != null
                    ? maskAccountNumber(transaction.getFromAccount().getAccountNumber())
                    : "N/A";
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("From Account   : " + fromMasked);
            stream.endText();

            y -= lineHeight;
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("To Account     : " + maskAccountNumber(transaction.getToAccount().getAccountNumber()));
            stream.endText();

            y -= lineHeight;
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("Amount         : $" + String.format("%.2f", transaction.getAmount()));
            stream.endText();

            y -= lineHeight;
            String description = transaction.getDescription() != null ? transaction.getDescription() : "";
            stream.beginText();
            stream.setFont(regularFont, 12);
            stream.newLineAtOffset(50, y);
            stream.showText("Description    : " + description);
            stream.endText();

            // Footer
            stream.beginText();
            stream.setFont(regularFont, 9);
            stream.newLineAtOffset(50, 50);
            stream.showText("Generated: " + LocalDateTime.now());
            stream.endText();
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        doc.save(outputStream);
        doc.close();

        return outputStream.toByteArray();
    }

    private String maskAccountNumber(String accountNumber) {
        if (accountNumber.length() > 4) {
            return "****" + accountNumber.substring(accountNumber.length() - 4);
        }
        return accountNumber;
    }

    public byte[] generateHistoryPdf(String accountNumber, String currentUsername) throws Exception {
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found: " + accountNumber));

        if (!account.getOwner().getUsername().equals(currentUsername)) {
            throw new SecurityException("Access denied.");
        }

        List<Transaction> transactions = transactionRepository.findByAccountIdOrderByTimestampDesc(account.getId());

        PDDocument doc = new PDDocument();
        PDType1Font boldFont    = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        PDType1Font regularFont = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        PDType1Font smallFont   = new PDType1Font(Standard14Fonts.FontName.HELVETICA);

        // --- Page 1 header ---
        PDPage page = new PDPage(PDRectangle.A4);
        doc.addPage(page);
        PDPageContentStream stream = new PDPageContentStream(doc, page);

        stream.beginText();
        stream.setFont(boldFont, 16);
        stream.newLineAtOffset(50, 800);
        stream.showText("SecureBank — Transaction History");
        stream.endText();

        stream.beginText();
        stream.setFont(regularFont, 10);
        stream.newLineAtOffset(50, 782);
        stream.showText("Account: " + maskAccountNumber(accountNumber) + "   Generated: " + LocalDateTime.now());
        stream.endText();

        stream.moveTo(50, 774); stream.lineTo(545, 774); stream.stroke();

        // Column headers
        float y = 755;
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(50,  y); stream.showText("Date & Time");        stream.endText();
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(175, y); stream.showText("Type");               stream.endText();
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(240, y); stream.showText("From");               stream.endText();
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(320, y); stream.showText("To");                 stream.endText();
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(400, y); stream.showText("Amount");             stream.endText();
        stream.beginText(); stream.setFont(boldFont, 9); stream.newLineAtOffset(460, y); stream.showText("Description");        stream.endText();
        y -= 4;
        stream.moveTo(50, y); stream.lineTo(545, y); stream.stroke();
        y -= 14;

        for (Transaction tx : transactions) {
            if (y < 50) {
                stream.close();
                page = new PDPage(PDRectangle.A4);
                doc.addPage(page);
                stream = new PDPageContentStream(doc, page);
                y = 800;
            }

            String date = tx.getTimestamp() != null ? tx.getTimestamp().toString().replace("T", " ").substring(0, 16) : "";
            String type = tx.getType() != null ? tx.getType().toString() : "";
            String from = tx.getFromAccount() != null ? maskAccountNumber(tx.getFromAccount().getAccountNumber()) : "—";
            String to   = tx.getToAccount()   != null ? maskAccountNumber(tx.getToAccount().getAccountNumber())   : "—";
            String amt  = "$" + String.format("%.2f", tx.getAmount());
            String desc = tx.getDescription() != null ? tx.getDescription() : "";
            if (desc.length() > 18) desc = desc.substring(0, 15) + "...";

            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(50,  y); stream.showText(date); stream.endText();
            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(175, y); stream.showText(type); stream.endText();
            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(240, y); stream.showText(from); stream.endText();
            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(320, y); stream.showText(to);   stream.endText();
            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(400, y); stream.showText(amt);  stream.endText();
            stream.beginText(); stream.setFont(smallFont, 8); stream.newLineAtOffset(460, y); stream.showText(desc); stream.endText();

            y -= 14;
            stream.moveTo(50, y + 2); stream.lineTo(545, y + 2); stream.setLineWidth(0.3f); stream.stroke();
        }

        stream.close();

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        doc.save(out);
        doc.close();
        return out.toByteArray();
    }
}
