package com.example.onlinebankingsystem.service;

import com.example.onlinebankingsystem.dto.TransactionDto;
import com.example.onlinebankingsystem.dto.TransactionFilterParams;
import com.example.onlinebankingsystem.dto.TransferRequestDto;
import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.repository.AccountRepository;
import com.example.onlinebankingsystem.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Crucial for atomicity

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TransactionService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Transactional // Ensures the entire transfer operation is atomic
    public TransactionDto transferFunds(TransferRequestDto transferRequest, String currentUsername) {
        // 1. Validate accounts
        Account fromAccount = accountRepository.findByAccountNumber(transferRequest.getFromAccountNumber())
                .orElseThrow(() -> new IllegalArgumentException("Source account not found: " + transferRequest.getFromAccountNumber()));
        Account toAccount = accountRepository.findByAccountNumber(transferRequest.getToAccountNumber())
                .orElseThrow(() -> new IllegalArgumentException("Destination account not found: " + transferRequest.getToAccountNumber()));

        // 2. Check ownership of the source account
        if (!fromAccount.getOwner().getUsername().equals(currentUsername)) {
            throw new SecurityException("User does not own the source account.");
        }

        // 3. Check for sufficient funds
        if (fromAccount.getBalance().compareTo(transferRequest.getAmount()) < 0) {
            throw new IllegalArgumentException("Insufficient funds in source account.");
        }

        // 4. Perform the transfer
        fromAccount.setBalance(fromAccount.getBalance().subtract(transferRequest.getAmount()));
        toAccount.setBalance(toAccount.getBalance().add(transferRequest.getAmount()));

        // 5. Save updated accounts
        accountRepository.save(fromAccount);
        accountRepository.save(toAccount);

        // 6. Create and save the transaction record
        Transaction transaction = new Transaction();
        transaction.setFromAccount(fromAccount);
        transaction.setToAccount(toAccount);
        transaction.setAmount(transferRequest.getAmount());
        transaction.setType(Transaction.TransactionType.TRANSFER);
        transaction.setDescription(transferRequest.getDescription());
        // timestamp is set by @PrePersist

        Transaction savedTransaction = transactionRepository.save(transaction);

        return convertToDto(savedTransaction);
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> getTransactionHistory(String accountNumber, String currentUsername) {
        // 1. Find the account
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found: " + accountNumber));

        // 2. Check ownership
        if (!account.getOwner().getUsername().equals(currentUsername)) {
            throw new SecurityException("User does not own this account.");
        }

        // 3. Retrieve transactions
        List<Transaction> transactions = transactionRepository.findByAccountIdOrderByTimestampDesc(account.getId());

        // 4. Convert to DTOs
        return transactions.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> getRecentTransactions(String accountNumber, String currentUsername) {
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found: " + accountNumber));
        if (!account.getOwner().getUsername().equals(currentUsername)) {
            throw new SecurityException("User does not own this account.");
        }
        return transactionRepository.findTop10ByAccountId(account.getId())
                .stream().map(this::convertToDto).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> getFilteredHistory(String accountNumber, TransactionFilterParams filter, String currentUsername) {
        // 1. Find the account
        Account account = accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found: " + accountNumber));

        // 2. Validate ownership
        if (!account.getOwner().getUsername().equals(currentUsername)) {
            throw new SecurityException("User does not own this account.");
        }

        // 3. Validate date ordering
        if (filter.getStartDate() != null && filter.getEndDate() != null) {
            if (filter.getStartDate().isAfter(filter.getEndDate())) {
                throw new IllegalArgumentException("startDate must be before or equal to endDate.");
            }
        }

        // 4. Validate amount ordering
        if (filter.getMinAmount() != null && filter.getMaxAmount() != null) {
            if (filter.getMinAmount().compareTo(filter.getMaxAmount()) > 0) {
                throw new IllegalArgumentException("minAmount must be less than or equal to maxAmount.");
            }
        }

        // 5. Delegate to repository
        List<Transaction> transactions = transactionRepository.findByAccountAndFilters(
                account.getId(),
                filter.getStartDate(),
                filter.getEndDate(),
                filter.getType(),
                filter.getMinAmount(),
                filter.getMaxAmount()
        );

        // 6. Map to DTOs
        return transactions.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    // --- Helper Method ---

    private TransactionDto convertToDto(Transaction transaction) {
        boolean receiptAvailable = transaction.getType() == Transaction.TransactionType.TRANSFER;
        return new TransactionDto(
                transaction.getId(),
                transaction.getFromAccount() != null ? transaction.getFromAccount().getAccountNumber() : null, // Handle potential null fromAccount (e.g., deposits)
                transaction.getToAccount().getAccountNumber(),
                transaction.getAmount(),
                transaction.getTimestamp(),
                transaction.getType(),
                transaction.getDescription(),
                receiptAvailable
        );
    }
}
