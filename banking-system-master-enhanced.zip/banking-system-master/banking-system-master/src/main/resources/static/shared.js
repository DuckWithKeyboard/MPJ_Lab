// shared.js — Auth/API helpers shared across all pages

const API_BASE_URL = '/api';

// ── Storage ───────────────────────────────────────────────────────────────────
// sessionStorage: survives page navigations within the same tab,
// but is automatically cleared when the tab/window is closed.
// No beforeunload needed — the browser handles cleanup.

function getJwt() {
    return sessionStorage.getItem('jwtToken');
}
function setJwt(token) {
    sessionStorage.setItem('jwtToken', token);
}
function clearJwt() {
    sessionStorage.removeItem('jwtToken');
}

function getCurrentUsername() {
    return sessionStorage.getItem('currentUsername');
}
function setCurrentUsername(name) {
    sessionStorage.setItem('currentUsername', name);
}
function clearCurrentUsername() {
    sessionStorage.removeItem('currentUsername');
}

// Clean up any stale keys left in localStorage from old builds
localStorage.removeItem('jwtToken');
localStorage.removeItem('currentUsername');
localStorage.removeItem('username');

// ── Inactivity timer ──────────────────────────────────────────────────────────
const INACTIVITY_TIMEOUT_MS = 5 * 60 * 1000;
let _inactivityTimer = null;

function _resetInactivityTimer() {
    clearTimeout(_inactivityTimer);
    _inactivityTimer = setTimeout(() => {
        if (getJwt()) {
            clearJwt();
            clearCurrentUsername();
            window.location.replace('landing.html');
        }
    }, INACTIVITY_TIMEOUT_MS);
}

function startInactivityTimer() {
    ['mousemove', 'keydown', 'mousedown', 'touchstart', 'scroll', 'click'].forEach(evt =>
        document.addEventListener(evt, _resetInactivityTimer, { passive: true })
    );
    _resetInactivityTimer();
}

// ── Auth guard ────────────────────────────────────────────────────────────────
function requireAuth() {
    if (!getJwt()) {
        window.location.replace('landing.html');
    }
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function maskAccountNumber(num) {
    if (!num) return 'N/A';
    const str = String(num);
    return str.length > 4 ? '****' + str.slice(-4) : str;
}

// ── API request ───────────────────────────────────────────────────────────────
async function apiRequest(endpoint, method = 'GET', body = null, requiresAuth = true) {
    const headers = { 'Content-Type': 'application/json' };
    if (requiresAuth) {
        const token = getJwt();
        if (token) {
            headers['Authorization'] = 'Bearer ' + token;
        } else {
            console.warn('apiRequest: no JWT in sessionStorage for', endpoint);
        }
    }
    const options = { method, headers };
    if (body !== null) options.body = JSON.stringify(body);
    return await fetch(API_BASE_URL + endpoint, options);
}
