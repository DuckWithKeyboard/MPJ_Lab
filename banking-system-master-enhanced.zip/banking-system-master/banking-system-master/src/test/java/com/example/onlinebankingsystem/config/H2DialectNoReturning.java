package com.example.onlinebankingsystem.config;

import org.hibernate.dialect.H2Dialect;

/**
 * H2 dialect that disables the RETURNING clause so integration tests
 * work with H2 in-memory databases (H2 does not support RETURNING).
 */
public class H2DialectNoReturning extends H2Dialect {
    @Override
    public boolean supportsInsertReturningGeneratedKeys() {
        return false;
    }

    @Override
    public boolean useFollowOnLocking(String sql, org.hibernate.query.spi.QueryOptions queryOptions) {
        return false;
    }
}
