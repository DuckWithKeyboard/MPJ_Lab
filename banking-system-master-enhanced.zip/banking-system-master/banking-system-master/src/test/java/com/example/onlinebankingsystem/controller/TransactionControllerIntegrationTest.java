package com.example.onlinebankingsystem.controller;

import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.model.User;
import com.example.onlinebankingsystem.repository.AccountRepository;
import com.example.onlinebankingsystem.repository.TransactionRepository;
import com.example.onlinebankingsystem.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestPropertySource(properties = {
    "spring.datasource.url=jdbc:h2:mem:itestdb;DB_CLOSE_DELAY=-1;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE",
    "spring.datasource.driver-class-name=org.h2.Driver",
    "spring.jpa.database-platform=com.example.onlinebankingsystem.config.H2DialectNoReturning",
    "spring.jpa.hibernate.ddl-auto=create-drop",
    "spring.jpa.properties.hibernate.dialect=com.example.onlinebankingsystem.config.H2DialectNoReturning"
})
class TransactionControllerIntegrationTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired UserRepository userRepository;
    @Autowired AccountRepository accountRepository;
    @Autowired TransactionRepository transactionRepository;
    @Autowired PasswordEncoder passwordEncoder;

    private Account accountA;
    private Account accountB;
    private static final String USERNAME = "testuser";

    @BeforeEach
    void setUp() {
        User user = new User();
        user.setUsername(USERNAME);
        user.setPassword(passwordEncoder.encode("password"));
        user.setEmail("test@example.com");
        user.setRoles(Set.of("ROLE_USER"));
        user = userRepository.save(user);

        accountA = new Account();
        accountA.setAccountNumber("ACC-AAA-001");
        accountA.setBalance(BigDecimal.valueOf(1000));
        accountA.setAccountType(Account.AccountType.SAVINGS);
        accountA.setOwner(user);
        accountA = accountRepository.save(accountA);

        accountB = new Account();
        accountB.setAccountNumber("ACC-BBB-002");
        accountB.setBalance(BigDecimal.valueOf(500));
        accountB.setAccountType(Account.AccountType.CHECKING);
        accountB.setOwner(user);
        accountB = accountRepository.save(accountB);
    }

    // ── Transfer Tests ────────────────────────────────────────────────────────

    @Test
    @WithMockUser(username = USERNAME)
    void transfer_success_debitsAndCredits() throws Exception {
        var body = Map.of(
            "fromAccountNumber", "ACC-AAA-001",
            "toAccountNumber",   "ACC-BBB-002",
            "amount",            200,
            "description",       "test transfer"
        );

        mockMvc.perform(post("/api/transactions/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.type").value("TRANSFER"))
            .andExpect(jsonPath("$.amount").value(200))
            .andExpect(jsonPath("$.receiptAvailable").value(true));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void transfer_selfTransfer_success() throws Exception {
        // Transfer between own accounts (self-transfer)
        var body = Map.of(
            "fromAccountNumber", "ACC-AAA-001",
            "toAccountNumber",   "ACC-BBB-002",
            "amount",            100,
            "description",       "self transfer"
        );

        mockMvc.perform(post("/api/transactions/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.fromAccountNumber").value("ACC-AAA-001"))
            .andExpect(jsonPath("$.toAccountNumber").value("ACC-BBB-002"));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void transfer_insufficientFunds_returns400() throws Exception {
        var body = Map.of(
            "fromAccountNumber", "ACC-AAA-001",
            "toAccountNumber",   "ACC-BBB-002",
            "amount",            9999,
            "description",       "too much"
        );

        mockMvc.perform(post("/api/transactions/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
            .andExpect(status().isBadRequest())
            .andExpect(content().string(containsString("Insufficient funds")));
    }

    @Test
    @WithMockUser(username = "otheruser")
    void transfer_notOwner_returns403() throws Exception {
        var body = Map.of(
            "fromAccountNumber", "ACC-AAA-001",
            "toAccountNumber",   "ACC-BBB-002",
            "amount",            100,
            "description",       "unauthorized"
        );

        mockMvc.perform(post("/api/transactions/transfer")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
            .andExpect(status().isForbidden());
    }

    // ── Filter Tests ──────────────────────────────────────────────────────────

    @Test
    @WithMockUser(username = USERNAME)
    void filter_noParams_returnsAllTransactions() throws Exception {
        // Seed a transaction
        saveTransfer(accountA, accountB, BigDecimal.valueOf(50), LocalDateTime.now());

        mockMvc.perform(get("/api/transactions/history/ACC-AAA-001"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$", hasSize(greaterThanOrEqualTo(1))));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void filter_byType_returnsOnlyMatchingType() throws Exception {
        saveTransfer(accountA, accountB, BigDecimal.valueOf(100), LocalDateTime.now());

        mockMvc.perform(get("/api/transactions/history/ACC-AAA-001?type=TRANSFER"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$[*].type", everyItem(is("TRANSFER"))));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void filter_byAmountRange_returnsOnlyInRange() throws Exception {
        saveTransfer(accountA, accountB, BigDecimal.valueOf(50),  LocalDateTime.now());
        saveTransfer(accountA, accountB, BigDecimal.valueOf(200), LocalDateTime.now());
        saveTransfer(accountA, accountB, BigDecimal.valueOf(500), LocalDateTime.now());

        mockMvc.perform(get("/api/transactions/history/ACC-AAA-001?minAmount=100&maxAmount=300"))
            .andExpect(status().isOk())
            // Only the $200 transaction should be in range [100, 300]
            .andExpect(jsonPath("$", hasSize(1)))
            .andExpect(jsonPath("$[0].amount").value(200.0));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void filter_invalidDateRange_returns400() throws Exception {
        mockMvc.perform(get("/api/transactions/history/ACC-AAA-001?startDate=2026-04-23T10:00:00&endDate=2026-01-01T00:00:00"))
            .andExpect(status().isBadRequest());
    }

    @Test
    @WithMockUser(username = "otheruser")
    void filter_notOwner_returns403() throws Exception {
        mockMvc.perform(get("/api/transactions/history/ACC-AAA-001"))
            .andExpect(status().isForbidden());
    }

    // ── Receipt Tests ─────────────────────────────────────────────────────────

    @Test
    @WithMockUser(username = USERNAME)
    void receipt_validTransfer_returnsPdf() throws Exception {
        Transaction tx = saveTransfer(accountA, accountB, BigDecimal.valueOf(100), LocalDateTime.now());

        mockMvc.perform(get("/api/transactions/" + tx.getId() + "/receipt"))
            .andExpect(status().isOk())
            .andExpect(header().string("Content-Type", containsString("application/pdf")));
    }

    @Test
    @WithMockUser(username = USERNAME)
    void receipt_notFound_returns404() throws Exception {
        mockMvc.perform(get("/api/transactions/999999/receipt"))
            .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(username = "otheruser")
    void receipt_notOwner_returns403() throws Exception {
        Transaction tx = saveTransfer(accountA, accountB, BigDecimal.valueOf(100), LocalDateTime.now());

        mockMvc.perform(get("/api/transactions/" + tx.getId() + "/receipt"))
            .andExpect(status().isForbidden());
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    private Transaction saveTransfer(Account from, Account to, BigDecimal amount, LocalDateTime ts) {
        Transaction tx = new Transaction();
        tx.setFromAccount(from);
        tx.setToAccount(to);
        tx.setAmount(amount);
        tx.setType(Transaction.TransactionType.TRANSFER);
        tx.setTimestamp(ts);
        tx.setDescription("test");
        return transactionRepository.save(tx);
    }
}
