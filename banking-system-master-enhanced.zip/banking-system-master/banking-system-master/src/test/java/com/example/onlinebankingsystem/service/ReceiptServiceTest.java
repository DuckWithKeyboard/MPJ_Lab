package com.example.onlinebankingsystem.service;

import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.model.User;
import com.example.onlinebankingsystem.repository.TransactionRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Tests for ReceiptService covering Tasks 3.2, 3.3, and 3.4.
 */
class ReceiptServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private ReceiptService receiptService;

    /**
     * Point PDFBox's font cache at a writable temp directory so that the
     * FileSystemFontProvider can initialise cleanly even on machines that
     * have corrupt system fonts (e.g. mstmc.ttf on some Windows installs).
     */
    @BeforeAll
    static void configurePdfBoxFontCache() throws IOException {
        Path tempDir = Files.createTempDirectory("pdfbox-test-fontcache");
        System.setProperty("pdfbox.fontcache", tempDir.toAbsolutePath().toString());
    }

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private User makeUser(String username) {
        User user = new User();
        user.setUsername(username);
        return user;
    }

    private Account makeAccount(long id, String accountNumber, String ownerUsername) {
        Account account = new Account();
        account.setId(id);
        account.setAccountNumber(accountNumber);
        account.setBalance(BigDecimal.valueOf(1000));
        account.setAccountType(Account.AccountType.SAVINGS);
        account.setOwner(makeUser(ownerUsername));
        return account;
    }

    private Transaction makeTransfer(long id, Account from, Account to) {
        Transaction tx = new Transaction();
        tx.setId(id);
        tx.setFromAccount(from);
        tx.setToAccount(to);
        tx.setAmount(BigDecimal.valueOf(250.00));
        tx.setType(Transaction.TransactionType.TRANSFER);
        tx.setTimestamp(LocalDateTime.of(2024, 6, 15, 10, 30));
        tx.setDescription("Test transfer");
        return tx;
    }

    private Transaction makeDeposit(long id, Account to) {
        Transaction tx = new Transaction();
        tx.setId(id);
        tx.setFromAccount(null); // DEPOSIT has no fromAccount
        tx.setToAccount(to);
        tx.setAmount(BigDecimal.valueOf(500.00));
        tx.setType(Transaction.TransactionType.DEPOSIT);
        tx.setTimestamp(LocalDateTime.of(2024, 6, 16, 9, 0));
        tx.setDescription("Test deposit");
        return tx;
    }

    // =========================================================================
    // Task 3.2 — Property 6: Receipt Ownership Guard (Req 6.5)
    // =========================================================================

    record OwnershipScenario(
            String requestingUser,
            Transaction transaction,
            boolean expectException,
            String description
    ) {}

    static Stream<OwnershipScenario> ownershipScenarios() {
        ReceiptServiceTest helper = new ReceiptServiceTest();

        Account fromAccount = helper.makeAccount(1L, "ACC-FROM-001", "alice");
        Account toAccount   = helper.makeAccount(2L, "ACC-TO-002",   "bob");
        Account otherAccount = helper.makeAccount(3L, "ACC-OTHER-003", "charlie");

        Transaction transfer = helper.makeTransfer(10L, fromAccount, toAccount);

        Account depositTo = helper.makeAccount(4L, "ACC-DEP-004", "diana");
        Transaction deposit = helper.makeDeposit(20L, depositTo);

        return Stream.of(
                // User owns fromAccount only → no exception
                new OwnershipScenario("alice", transfer, false,
                        "user owns fromAccount only"),

                // User owns toAccount only → no exception
                new OwnershipScenario("bob", transfer, false,
                        "user owns toAccount only"),

                // User owns neither → SecurityException
                new OwnershipScenario("charlie", transfer, true,
                        "user owns neither account"),

                // fromAccount is null (DEPOSIT), user owns toAccount → no exception
                new OwnershipScenario("diana", deposit, false,
                        "DEPOSIT: fromAccount null, user owns toAccount"),

                // fromAccount is null (DEPOSIT), user owns neither → SecurityException
                new OwnershipScenario("eve", deposit, true,
                        "DEPOSIT: fromAccount null, user owns neither")
        );
    }

    /**
     * Property 6: Receipt Ownership Guard
     * Validates: Requirements 6.5
     *
     * generateReceipt throws SecurityException when the requesting user owns
     * neither fromAccount nor toAccount; succeeds otherwise.
     */
    @ParameterizedTest
    @MethodSource("ownershipScenarios")
    void property6_receiptOwnershipGuard(OwnershipScenario scenario) {
        when(transactionRepository.findById(scenario.transaction().getId()))
                .thenReturn(Optional.of(scenario.transaction()));

        if (scenario.expectException()) {
            assertThrows(SecurityException.class,
                    () -> receiptService.generateReceipt(
                            scenario.transaction().getId(), scenario.requestingUser()),
                    "Expected SecurityException for scenario: " + scenario.description());
        } else {
            assertDoesNotThrow(
                    () -> receiptService.generateReceipt(
                            scenario.transaction().getId(), scenario.requestingUser()),
                    "Expected no exception for scenario: " + scenario.description());
        }
    }

    // =========================================================================
    // Task 3.3 — Property 7: Receipt PDF Validity (Req 6.2)
    // =========================================================================

    record PdfValidityScenario(
            Transaction transaction,
            String requestingUser,
            String description
    ) {}

    static Stream<PdfValidityScenario> pdfValidityScenarios() {
        ReceiptServiceTest helper = new ReceiptServiceTest();

        Account from = helper.makeAccount(1L, "ACC-FROM-001", "alice");
        Account to   = helper.makeAccount(2L, "ACC-TO-002",   "bob");

        Transaction transfer = helper.makeTransfer(10L, from, to);

        Account depositTo = helper.makeAccount(3L, "ACC-DEP-003", "carol");
        Transaction deposit = helper.makeDeposit(20L, depositTo);

        return Stream.of(
                new PdfValidityScenario(transfer, "alice",
                        "TRANSFER: owner of fromAccount requests receipt"),
                new PdfValidityScenario(transfer, "bob",
                        "TRANSFER: owner of toAccount requests receipt"),
                new PdfValidityScenario(deposit, "carol",
                        "DEPOSIT: null fromAccount, owner of toAccount requests receipt")
        );
    }

    /**
     * Property 7: Receipt PDF Validity
     * Validates: Requirements 6.2
     *
     * For any successful generateReceipt call, the returned byte array must:
     * - have length > 0
     * - start with "%PDF" (first 4 bytes)
     */
    @ParameterizedTest
    @MethodSource("pdfValidityScenarios")
    void property7_receiptPdfValidity(PdfValidityScenario scenario) throws Exception {
        when(transactionRepository.findById(scenario.transaction().getId()))
                .thenReturn(Optional.of(scenario.transaction()));

        byte[] pdf = receiptService.generateReceipt(
                scenario.transaction().getId(), scenario.requestingUser());

        assertNotNull(pdf, "PDF bytes must not be null for: " + scenario.description());
        assertTrue(pdf.length > 0, "PDF bytes must be non-empty for: " + scenario.description());

        String header = new String(pdf, 0, 4);
        assertEquals("%PDF", header,
                "PDF must start with '%PDF' for: " + scenario.description());
    }

    // =========================================================================
    // Task 3.4 — Unit test for receipt idempotence (Req 6.4)
    // =========================================================================

    /**
     * Property 4 (receipt): generateReceipt idempotence
     * Validates: Requirements 6.4
     *
     * Calling generateReceipt twice for the same transaction ID returns byte arrays
     * that both start with "%PDF" (valid PDFs with equivalent content).
     * Exact byte equality is not required since the generated-at timestamp differs.
     * Length equality is also not asserted because the timestamp string length can
     * vary by one character (e.g. second "9" vs "10"), which is expected behaviour.
     */
    @Test
    void receiptIdempotence_transferTransaction() throws Exception {
        Account from = makeAccount(1L, "ACC-FROM-001", "alice");
        Account to   = makeAccount(2L, "ACC-TO-002",   "bob");
        Transaction transfer = makeTransfer(10L, from, to);

        when(transactionRepository.findById(10L))
                .thenReturn(Optional.of(transfer));

        byte[] first  = receiptService.generateReceipt(10L, "alice");
        byte[] second = receiptService.generateReceipt(10L, "alice");

        // Both must be non-empty valid PDFs
        assertTrue(first.length  > 0, "First call must return non-empty bytes");
        assertTrue(second.length > 0, "Second call must return non-empty bytes");
        assertEquals("%PDF", new String(first,  0, 4), "First call must return valid PDF");
        assertEquals("%PDF", new String(second, 0, 4), "Second call must return valid PDF");
    }

    @Test
    void receiptIdempotence_depositTransaction() throws Exception {
        Account to = makeAccount(3L, "ACC-DEP-003", "carol");
        Transaction deposit = makeDeposit(20L, to);

        when(transactionRepository.findById(20L))
                .thenReturn(Optional.of(deposit));

        byte[] first  = receiptService.generateReceipt(20L, "carol");
        byte[] second = receiptService.generateReceipt(20L, "carol");

        // Both must be non-empty valid PDFs
        assertTrue(first.length  > 0, "First call must return non-empty bytes");
        assertTrue(second.length > 0, "Second call must return non-empty bytes");
        assertEquals("%PDF", new String(first,  0, 4), "First call must return valid PDF");
        assertEquals("%PDF", new String(second, 0, 4), "Second call must return valid PDF");
    }
}
