package com.example.onlinebankingsystem.service;

import com.example.onlinebankingsystem.dto.TransactionDto;
import com.example.onlinebankingsystem.dto.TransactionFilterParams;
import com.example.onlinebankingsystem.model.Account;
import com.example.onlinebankingsystem.model.Transaction;
import com.example.onlinebankingsystem.model.User;
import com.example.onlinebankingsystem.repository.AccountRepository;
import com.example.onlinebankingsystem.repository.TransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Property-based tests for TransactionService.getFilteredHistory().
 *
 * Tasks 2.3–2.7 from the fund-transfer-history-receipts spec.
 */
class TransactionServiceFilterTest {

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private TransactionService transactionService;

    private static final String TEST_USERNAME = "testuser";
    private static final String ACCOUNT_NUMBER = "ACC-001";

    private Account testAccount;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        User owner = new User();
        owner.setUsername(TEST_USERNAME);

        testAccount = new Account();
        testAccount.setId(1L);
        testAccount.setAccountNumber(ACCOUNT_NUMBER);
        testAccount.setOwner(owner);
        testAccount.setBalance(BigDecimal.valueOf(10000));
        testAccount.setAccountType(Account.AccountType.SAVINGS);

        when(accountRepository.findByAccountNumber(ACCOUNT_NUMBER))
                .thenReturn(Optional.of(testAccount));
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Transaction makeTransaction(long id, Transaction.TransactionType type,
                                        BigDecimal amount, LocalDateTime timestamp) {
        Account from = new Account();
        from.setAccountNumber("FROM-" + id);

        Account to = new Account();
        to.setAccountNumber("TO-" + id);

        Transaction tx = new Transaction();
        tx.setId(id);
        tx.setFromAccount(from);
        tx.setToAccount(to);
        tx.setAmount(amount);
        tx.setType(type);
        tx.setTimestamp(timestamp);
        tx.setDescription("desc-" + id);
        return tx;
    }

    /** Stub the repository to return the given transactions for any filter call. */
    private void stubRepo(List<Transaction> transactions) {
        when(transactionRepository.findByAccountAndFilters(
                eq(testAccount.getId()),
                any(), any(), any(), any(), any()))
                .thenReturn(transactions);
    }

    // =========================================================================
    // Task 2.3 — Property 2: Filtered History — Date Bounds (Req 5.3)
    // =========================================================================

    record DateBoundsScenario(
            LocalDateTime startDate,
            LocalDateTime endDate,
            List<Transaction> transactions
    ) {}

    static Stream<DateBoundsScenario> dateBoundsScenarios() {
        LocalDateTime base = LocalDateTime.of(2024, 1, 15, 12, 0);

        // Transactions at various timestamps
        Transaction t1 = new TransactionServiceFilterTest().txAt(1L, base.minusDays(5));  // before range
        Transaction t2 = new TransactionServiceFilterTest().txAt(2L, base);               // at start
        Transaction t3 = new TransactionServiceFilterTest().txAt(3L, base.plusDays(3));   // inside range
        Transaction t4 = new TransactionServiceFilterTest().txAt(4L, base.plusDays(7));   // at end
        Transaction t5 = new TransactionServiceFilterTest().txAt(5L, base.plusDays(10));  // after range

        return Stream.of(
                // Only startDate set — repo returns items at/after start
                new DateBoundsScenario(base, null, List.of(t2, t3, t4)),
                // Only endDate set — repo returns items at/before end
                new DateBoundsScenario(null, base.plusDays(7), List.of(t2, t3, t4)),
                // Both bounds — repo returns items within [start, end]
                new DateBoundsScenario(base, base.plusDays(7), List.of(t2, t3, t4)),
                // Exact single-point range
                new DateBoundsScenario(base, base, List.of(t2)),
                // No date filter — all items returned
                new DateBoundsScenario(null, null, List.of(t1, t2, t3, t4, t5))
        );
    }

    /** Helper usable from static context via default constructor. */
    private Transaction txAt(long id, LocalDateTime ts) {
        return makeTransaction(id, Transaction.TransactionType.DEPOSIT, BigDecimal.TEN, ts);
    }

    /**
     * Property 2: Filtered History — Date Bounds
     * Validates: Requirements 5.3
     *
     * For any filter with startDate and/or endDate, all returned TransactionDtos
     * must have timestamps within [startDate, endDate].
     */
    @ParameterizedTest
    @MethodSource("dateBoundsScenarios")
    void property2_dateBounds(DateBoundsScenario scenario) {
        stubRepo(scenario.transactions());

        TransactionFilterParams filter = new TransactionFilterParams(
                scenario.startDate(), scenario.endDate(), null, null, null);

        List<TransactionDto> result = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, filter, TEST_USERNAME);

        for (TransactionDto dto : result) {
            if (scenario.startDate() != null) {
                assertFalse(dto.getTimestamp().isBefore(scenario.startDate()),
                        "timestamp " + dto.getTimestamp() + " is before startDate " + scenario.startDate());
            }
            if (scenario.endDate() != null) {
                assertFalse(dto.getTimestamp().isAfter(scenario.endDate()),
                        "timestamp " + dto.getTimestamp() + " is after endDate " + scenario.endDate());
            }
        }
    }

    // =========================================================================
    // Task 2.4 — Property 3: Filtered History — Type Predicate (Req 5.4)
    // =========================================================================

    record TypePredicateScenario(
            Transaction.TransactionType filterType,
            List<Transaction> transactions
    ) {}

    static Stream<TypePredicateScenario> typePredicateScenarios() {
        LocalDateTime ts = LocalDateTime.of(2024, 3, 1, 10, 0);
        TransactionServiceFilterTest helper = new TransactionServiceFilterTest();

        Transaction transfer1 = helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(100), ts);
        Transaction transfer2 = helper.makeTransaction(2L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(200), ts.plusHours(1));
        Transaction deposit1  = helper.makeTransaction(3L, Transaction.TransactionType.DEPOSIT,  BigDecimal.valueOf(500), ts.plusHours(2));
        Transaction withdrawal = helper.makeTransaction(4L, Transaction.TransactionType.WITHDRAWAL, BigDecimal.valueOf(50), ts.plusHours(3));

        return Stream.of(
                new TypePredicateScenario(Transaction.TransactionType.TRANSFER,   List.of(transfer1, transfer2)),
                new TypePredicateScenario(Transaction.TransactionType.DEPOSIT,    List.of(deposit1)),
                new TypePredicateScenario(Transaction.TransactionType.WITHDRAWAL, List.of(withdrawal)),
                // Single item of each type
                new TypePredicateScenario(Transaction.TransactionType.TRANSFER,   List.of(transfer1)),
                // Empty result is valid
                new TypePredicateScenario(Transaction.TransactionType.DEPOSIT,    List.of())
        );
    }

    /**
     * Property 3: Filtered History — Type Predicate
     * Validates: Requirements 5.4
     *
     * For any filter with a type, all returned TransactionDtos must have that exact type.
     */
    @ParameterizedTest
    @MethodSource("typePredicateScenarios")
    void property3_typePredicate(TypePredicateScenario scenario) {
        stubRepo(scenario.transactions());

        TransactionFilterParams filter = new TransactionFilterParams(
                null, null, scenario.filterType(), null, null);

        List<TransactionDto> result = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, filter, TEST_USERNAME);

        for (TransactionDto dto : result) {
            assertEquals(scenario.filterType(), dto.getType(),
                    "Expected type " + scenario.filterType() + " but got " + dto.getType());
        }
    }

    // =========================================================================
    // Task 2.5 — Property 4: Filtered History — Amount Bounds (Req 5.5)
    // =========================================================================

    record AmountBoundsScenario(
            BigDecimal minAmount,
            BigDecimal maxAmount,
            List<Transaction> transactions
    ) {}

    static Stream<AmountBoundsScenario> amountBoundsScenarios() {
        LocalDateTime ts = LocalDateTime.of(2024, 4, 1, 9, 0);
        TransactionServiceFilterTest helper = new TransactionServiceFilterTest();

        Transaction t10  = helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(10),   ts);
        Transaction t50  = helper.makeTransaction(2L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(50),   ts.plusMinutes(1));
        Transaction t100 = helper.makeTransaction(3L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(100),  ts.plusMinutes(2));
        Transaction t500 = helper.makeTransaction(4L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(500),  ts.plusMinutes(3));

        return Stream.of(
                // Only minAmount
                new AmountBoundsScenario(BigDecimal.valueOf(50), null, List.of(t50, t100, t500)),
                // Only maxAmount
                new AmountBoundsScenario(null, BigDecimal.valueOf(100), List.of(t10, t50, t100)),
                // Both bounds
                new AmountBoundsScenario(BigDecimal.valueOf(50), BigDecimal.valueOf(100), List.of(t50, t100)),
                // Exact single value
                new AmountBoundsScenario(BigDecimal.valueOf(100), BigDecimal.valueOf(100), List.of(t100)),
                // No amount filter
                new AmountBoundsScenario(null, null, List.of(t10, t50, t100, t500)),
                // Empty result
                new AmountBoundsScenario(BigDecimal.valueOf(1000), BigDecimal.valueOf(2000), List.of())
        );
    }

    /**
     * Property 4: Filtered History — Amount Bounds
     * Validates: Requirements 5.5
     *
     * For any filter with minAmount and/or maxAmount, all returned TransactionDtos
     * must have amounts within [minAmount, maxAmount].
     */
    @ParameterizedTest
    @MethodSource("amountBoundsScenarios")
    void property4_amountBounds(AmountBoundsScenario scenario) {
        stubRepo(scenario.transactions());

        TransactionFilterParams filter = new TransactionFilterParams(
                null, null, null, scenario.minAmount(), scenario.maxAmount());

        List<TransactionDto> result = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, filter, TEST_USERNAME);

        for (TransactionDto dto : result) {
            if (scenario.minAmount() != null) {
                assertTrue(dto.getAmount().compareTo(scenario.minAmount()) >= 0,
                        "amount " + dto.getAmount() + " is below minAmount " + scenario.minAmount());
            }
            if (scenario.maxAmount() != null) {
                assertTrue(dto.getAmount().compareTo(scenario.maxAmount()) <= 0,
                        "amount " + dto.getAmount() + " is above maxAmount " + scenario.maxAmount());
            }
        }
    }

    // =========================================================================
    // Task 2.6 — Property 8: Filter Idempotence (Req 5.6)
    // =========================================================================

    record IdempotenceScenario(
            TransactionFilterParams filter,
            List<Transaction> transactions,
            String description
    ) {}

    static Stream<IdempotenceScenario> idempotenceScenarios() {
        LocalDateTime ts = LocalDateTime.of(2024, 5, 1, 8, 0);
        TransactionServiceFilterTest helper = new TransactionServiceFilterTest();

        List<Transaction> mixed = List.of(
                helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER,   BigDecimal.valueOf(200), ts),
                helper.makeTransaction(2L, Transaction.TransactionType.DEPOSIT,    BigDecimal.valueOf(500), ts.plusHours(1)),
                helper.makeTransaction(3L, Transaction.TransactionType.WITHDRAWAL, BigDecimal.valueOf(75),  ts.plusHours(2))
        );

        return Stream.of(
                new IdempotenceScenario(
                        new TransactionFilterParams(null, null, null, null, null),
                        mixed,
                        "no filters"
                ),
                new IdempotenceScenario(
                        new TransactionFilterParams(ts, ts.plusHours(3), null, null, null),
                        List.of(helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(200), ts)),
                        "date range filter"
                ),
                new IdempotenceScenario(
                        new TransactionFilterParams(null, null, Transaction.TransactionType.TRANSFER, null, null),
                        List.of(helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(200), ts)),
                        "type filter"
                ),
                new IdempotenceScenario(
                        new TransactionFilterParams(null, null, null, BigDecimal.valueOf(100), BigDecimal.valueOf(300)),
                        List.of(helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(200), ts)),
                        "amount range filter"
                ),
                new IdempotenceScenario(
                        new TransactionFilterParams(null, null, null, null, null),
                        List.of(),
                        "empty result"
                )
        );
    }

    /**
     * Property 8: Filter Idempotence
     * Validates: Requirements 5.6
     *
     * Calling getFilteredHistory twice with identical parameters returns the same
     * result set in the same order (assuming no writes between calls).
     */
    @ParameterizedTest
    @MethodSource("idempotenceScenarios")
    void property8_filterIdempotence(IdempotenceScenario scenario) {
        stubRepo(scenario.transactions());

        List<TransactionDto> first  = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, scenario.filter(), TEST_USERNAME);
        List<TransactionDto> second = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, scenario.filter(), TEST_USERNAME);

        assertEquals(first.size(), second.size(),
                "Result sizes differ on second call for scenario: " + scenario.description());

        for (int i = 0; i < first.size(); i++) {
            TransactionDto a = first.get(i);
            TransactionDto b = second.get(i);
            assertEquals(a.getId(), b.getId(),
                    "ID mismatch at index " + i + " for scenario: " + scenario.description());
            assertEquals(a.getAmount(), b.getAmount(),
                    "Amount mismatch at index " + i);
            assertEquals(a.getType(), b.getType(),
                    "Type mismatch at index " + i);
            assertEquals(a.getTimestamp(), b.getTimestamp(),
                    "Timestamp mismatch at index " + i);
        }
    }

    // =========================================================================
    // Task 2.7 — Property 5: Receipt Availability Flag (Req 6.1)
    // =========================================================================

    record ReceiptFlagScenario(
            List<Transaction> transactions,
            String description
    ) {}

    static Stream<ReceiptFlagScenario> receiptFlagScenarios() {
        LocalDateTime ts = LocalDateTime.of(2024, 6, 1, 7, 0);
        TransactionServiceFilterTest helper = new TransactionServiceFilterTest();

        return Stream.of(
                new ReceiptFlagScenario(
                        List.of(helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER, BigDecimal.valueOf(100), ts)),
                        "single TRANSFER"
                ),
                new ReceiptFlagScenario(
                        List.of(helper.makeTransaction(2L, Transaction.TransactionType.DEPOSIT, BigDecimal.valueOf(200), ts)),
                        "single DEPOSIT"
                ),
                new ReceiptFlagScenario(
                        List.of(helper.makeTransaction(3L, Transaction.TransactionType.WITHDRAWAL, BigDecimal.valueOf(50), ts)),
                        "single WITHDRAWAL"
                ),
                new ReceiptFlagScenario(
                        List.of(
                                helper.makeTransaction(1L, Transaction.TransactionType.TRANSFER,   BigDecimal.valueOf(100), ts),
                                helper.makeTransaction(2L, Transaction.TransactionType.DEPOSIT,    BigDecimal.valueOf(200), ts.plusHours(1)),
                                helper.makeTransaction(3L, Transaction.TransactionType.WITHDRAWAL, BigDecimal.valueOf(50),  ts.plusHours(2)),
                                helper.makeTransaction(4L, Transaction.TransactionType.TRANSFER,   BigDecimal.valueOf(300), ts.plusHours(3))
                        ),
                        "mixed types"
                ),
                new ReceiptFlagScenario(
                        List.of(),
                        "empty list"
                )
        );
    }

    /**
     * Property 5: Receipt Availability Flag
     * Validates: Requirements 6.1
     *
     * For every TransactionDto returned, receiptAvailable == (type == TRANSFER).
     */
    @ParameterizedTest
    @MethodSource("receiptFlagScenarios")
    void property5_receiptAvailableFlag(ReceiptFlagScenario scenario) {
        stubRepo(scenario.transactions());

        TransactionFilterParams filter = new TransactionFilterParams(null, null, null, null, null);

        List<TransactionDto> result = transactionService.getFilteredHistory(
                ACCOUNT_NUMBER, filter, TEST_USERNAME);

        for (TransactionDto dto : result) {
            boolean expectedFlag = dto.getType() == Transaction.TransactionType.TRANSFER;
            assertEquals(expectedFlag, dto.isReceiptAvailable(),
                    "receiptAvailable mismatch for type " + dto.getType()
                            + " in scenario: " + scenario.description());
        }
    }
}
